import { valuesData, ValueCategory } from "@/lib/data";
import { useState } from "react";
import { useStudent } from "@/contexts/StudentContext";
import { ValueCard } from "@/components/ValueCard";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { LogOut, ArrowRight, LayoutDashboard, Trophy } from "lucide-react";
import { Footer } from "@/components/Footer";
import { LoginDialog } from "@/components/LoginDialog";
import { PrayerTracker } from "@/components/PrayerTracker";

export default function Home() {
  const { currentStudent, logout } = useStudent();
  const [selectedCategory, setSelectedCategory] = useState<ValueCategory | "all">("all");

  // قيمة الأسبوع (يمكن تغييرها ديناميكياً لاحقاً)
  const valueOfWeek = valuesData.find(v => v.id === "honesty");

  const filteredValues = selectedCategory === "all" 
    ? valuesData 
    : valuesData.filter(v => v.category === selectedCategory);

  const welcomeTitle = currentStudent?.gender === "girl" ? "مرحباً بكِ يا بطلة القيم!" : "مرحباً بك يا بطل القيم!";
  const guideImage = currentStudent?.gender === "girl" ? "/images/guide-girl.png" : "/images/guide-boy.png";

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <img src="/images/school-logo.png" alt="مدارس مدينة العلوم العالمية" className="w-8 h-8 sm:w-10 sm:h-10 object-contain" />
            <div className="hidden sm:block h-8 w-px bg-gray-200" />
            <div className="flex items-center gap-1 sm:gap-2">
              <div className="w-7 h-7 sm:w-8 sm:h-8 bg-primary rounded-lg flex items-center justify-center text-white font-bold text-lg sm:text-xl">ق</div>
              <h1 className="text-lg sm:text-xl font-bold text-primary">قِيَمي</h1>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-primary font-bold">الرئيسية</Link>
            <Link href="/achievements" className="text-muted-foreground hover:text-primary transition-colors">إنجازاتي</Link>


          </nav>

          {currentStudent ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-sm font-bold text-foreground">{currentStudent.name}</span>
                <span className="text-xs text-muted-foreground">{currentStudent.grade}</span>
              </div>
              <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center border-2 border-white shadow-sm overflow-hidden">
                <img src={currentStudent.gender === "girl" ? "/images/guide-girl.png" : "/images/guide-boy.png"} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <Button variant="ghost" size="icon" onClick={logout} className="text-red-500 hover:text-red-600 hover:bg-red-50">
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          ) : (
            <LoginDialog />
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative mb-12">
        <div className="h-[300px] w-full overflow-hidden relative">
          <img 
            src="/images/hero-student.png" 
            alt="Welcome Student" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#FDFBF7] to-transparent" />
          
          <div className="absolute bottom-0 left-0 right-0 p-8 text-center z-10">
            <h2 className="text-4xl md:text-5xl font-extrabold text-primary mb-4 drop-shadow-sm">
              {welcomeTitle} 🌟
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {currentStudent?.gender === "girl" ? "أنتِ" : "أنت"} في رحلة رائعة لتعلم القيم الجميلة. {currentStudent?.gender === "girl" ? "اختاري" : "اختر"} قيمة {currentStudent?.gender === "girl" ? "وابدئي" : "وابدأ"} مغامرتك اليوم {currentStudent?.gender === "girl" ? "لتصبحي قائدة" : "لتصبح قائداً"} للمستقبل.
            </p>
          </div>
          
          {/* الشخصية التفاعلية */}
          <div className="absolute bottom-0 right-10 hidden lg:block w-64 h-64 animate-in slide-in-from-bottom-10 duration-1000">
            <img src={guideImage} alt="Guide Character" className="w-full h-full object-contain drop-shadow-2xl" />
          </div>
        </div>
        
        {/* زر التمرير للأسفل */}
        <div className="absolute -bottom-12 left-1/2 scroll-bounce z-20 flex flex-col items-center gap-2">
          <button 
            onClick={() => document.getElementById('values-section')?.scrollIntoView({ behavior: 'smooth' })}
            className="w-16 h-16 bg-white rounded-full shadow-xl border-4 border-gray-100 flex items-center justify-center hover:shadow-2xl hover:scale-110 hover:bg-[#D4AF37] hover:border-[#D4AF37] transition-all duration-300 group"
          >
            <ArrowRight className="w-6 h-6 text-gray-600 rotate-90 group-hover:text-white transition-colors" />
          </button>
          <span className="text-sm font-medium text-gray-500 whitespace-nowrap">اكتشف القيم</span>
        </div>
      </section>

      {/* Values Grid */}
      <main id="values-section" className="container mx-auto px-4 pt-12">
        
        {/* قسم قيمة الأسبوع */}
        {valueOfWeek && (
          <div className="mb-12 bg-gradient-to-r from-primary/10 to-purple-100 rounded-3xl p-8 border-2 border-primary/20 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary via-purple-400 to-primary animate-pulse" />
            <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
              <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-xl border-4 border-white">
                <valueOfWeek.icon className="w-16 h-16 text-primary" />
              </div>
              <div className="flex-1 text-center md:text-right">
                <div className="inline-block bg-primary text-white px-4 py-1 rounded-full text-sm font-bold mb-3 shadow-sm">
                  🌟 قيمة الأسبوع
                </div>
                <h3 className="text-3xl font-bold text-gray-800 mb-2">{valueOfWeek.title}</h3>
                <p className="text-xl text-gray-600 mb-6 max-w-2xl">{valueOfWeek.description}</p>
                <Link href={`/activity/${valueOfWeek.id}`}>
                  <Button size="lg" className="rounded-full px-8 text-lg shadow-lg hover:shadow-xl transition-all hover:scale-105 bg-primary hover:bg-primary/90 text-white">
                    ابدأ تحدي الأسبوع
                  </Button>
                </Link>
              </div>
            </div>
            {/* زخارف خلفية */}
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-primary/5 rounded-full blur-3xl" />
            <div className="absolute top-10 left-10 w-20 h-20 bg-purple-500/5 rounded-full blur-2xl" />
          </div>
        )}

        {/* جدول متابعة الصلوات */}
        {currentStudent && (
          <div className="mb-12">
            <PrayerTracker />
          </div>
        )}

        <div className="flex flex-col lg:flex-row items-center justify-between mb-8 gap-4">
          <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <LayoutDashboard className="w-6 h-6 text-secondary" />
            مكتبة القيم
          </h3>
          
          {/* أزرار التصفية */}
          <div className="flex flex-wrap justify-center gap-2 bg-white p-2 rounded-xl shadow-sm border border-gray-100">
            <Button 
              variant={selectedCategory === "all" ? "default" : "ghost"} 
              onClick={() => setSelectedCategory("all")}
              className="rounded-lg"
            >
              الكل
            </Button>
            <Button 
              variant={selectedCategory === "faith" ? "default" : "ghost"} 
              onClick={() => setSelectedCategory("faith")}
              className="rounded-lg gap-2"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              قيم إيمانية
            </Button>
            <Button 
              variant={selectedCategory === "social" ? "default" : "ghost"} 
              onClick={() => setSelectedCategory("social")}
              className="rounded-lg gap-2"
            >
              <span className="w-2 h-2 rounded-full bg-blue-400" />
              قيم اجتماعية
            </Button>
            <Button 
              variant={selectedCategory === "personal" ? "default" : "ghost"} 
              onClick={() => setSelectedCategory("personal")}
              className="rounded-lg gap-2"
            >
              <span className="w-2 h-2 rounded-full bg-purple-400" />
              قيم شخصية
            </Button>
          </div>

          <Link href="/achievements">
            <Button variant="outline" className="gap-2 rounded-full border-2 hover:bg-secondary/10 hover:text-secondary-foreground hover:border-secondary">
              <Trophy className="w-4 h-4" />
              شاهد إنجازاتك
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredValues.map((value) => (
            <div key={value.id} className="h-full">
              <ValueCard value={value} />
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
