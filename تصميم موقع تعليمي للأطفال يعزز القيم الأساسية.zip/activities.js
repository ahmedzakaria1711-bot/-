// الأنشطة التفاعلية
function showQuizSelection() {
    const modal = document.getElementById('valueModal');
    modal.innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;"><span style="font-size: 4rem;">📝</span><h2>اختر قيمة للاختبار</h2></div>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
            ${valuesData.map(v => `<button onclick="startQuiz('${v.id}')" style="background: var(--bg-dark); border: 1px solid var(--border); color: var(--text-primary); padding: 1.5rem; border-radius: 12px; cursor: pointer; font-family: inherit; text-align: center;"><span style="font-size: 2rem; display: block; margin-bottom: 0.5rem;">${v.icon}</span><span>${v.name}</span></button>`).join('')}
        </div>
    </div>`;
    modal.classList.add('active');
}

function showStoriesPage() {
    const stories = [
        { id: 'honesty', title: 'قصة الصدق', icon: '🎯' },
        { id: 'trust', title: 'قصة الأمانة', icon: '🔐' },
        { id: 'respect', title: 'قصة الاحترام', icon: '🤝' },
        { id: 'cooperation', title: 'قصة التعاون', icon: '🤲' },
        { id: 'patience', title: 'قصة الصبر', icon: '🌿' }
    ];
    const modal = document.getElementById('valueModal');
    modal.innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;"><span style="font-size: 4rem;">📖</span><h2>قصص القيم</h2></div>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
            ${stories.map(s => `<button onclick="showStory('${s.id}')" style="background: var(--bg-dark); border: 1px solid var(--border); color: var(--text-primary); padding: 1.5rem; border-radius: 12px; cursor: pointer; font-family: inherit; text-align: right; display: flex; align-items: center; gap: 1rem;"><span style="font-size: 2rem;">${s.icon}</span><span>${s.title}</span></button>`).join('')}
        </div>
    </div>`;
    modal.classList.add('active');
}

function showStory(storyId) {
    const stories = {
        honesty: { title: 'قصة الصدق', icon: '🎯', story: 'كان هناك طفل صغير اسمه أحمد، كسر إناء أمه بالخطأ. فكر أن يكذب، لكنه تذكر أن الصدق منجاة. فأخبر أمه بالحقيقة، ففرحت به وقالت: "أنا فخورة بصدقك يا بني".' },
        trust: { title: 'قصة الأمانة', icon: '🔐', story: 'وجد سالم محفظة في الطريق فيها مال كثير. لم يأخذها لنفسه، بل بحث عن صاحبها وأعادها له. شكره الرجل وقال: "أنت أمين حقيقي".' },
        respect: { title: 'قصة الاحترام', icon: '🤝', story: 'كان خالد يحترم معلمه ووالديه وكبار السن. يسلم عليهم ويستمع لنصائحهم. فأحبه الجميع وصار قدوة لأصدقائه.' },
        cooperation: { title: 'قصة التعاون', icon: '🤲', story: 'تعاون طلاب الفصل في تنظيف مدرستهم. عمل كل واحد منهم بجد، فأنجزوا العمل بسرعة وفرحوا معاً بنتيجة تعاونهم.' },
        patience: { title: 'قصة الصبر', icon: '🌿', story: 'مرض والد يوسف، فصبر يوسف ورعاه بحب. بعد أيام شُفي والده، وقال له: "صبرك علامة إيمانك يا بني".' }
    };
    const s = stories[storyId];
    document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;"><span style="font-size: 4rem;">${s.icon}</span><h2>${s.title}</h2></div>
        <div style="background: var(--bg-dark); padding: 1.5rem; border-radius: 12px; margin-bottom: 2rem; line-height: 2;"><p>${s.story}</p></div>
        <button class="btn-primary" onclick="showStoriesPage()" style="width: 100%;">العودة للقصص</button>
    </div>`;
}

function showChallengesPage() {
    const challenges = [
        { id: 'honesty', title: 'تحدي الصدق', icon: '🎯', task: 'قل الحقيقة في كل موقف اليوم' },
        { id: 'respect', title: 'تحدي الاحترام', icon: '🤝', task: 'سلّم على 5 أشخاص من كبار السن' },
        { id: 'cooperation', title: 'تحدي التعاون', icon: '🤲', task: 'ساعد زميلاً في واجبه' },
        { id: 'gratitude', title: 'تحدي الشكر', icon: '🙏', task: 'اشكر 3 أشخاص على شيء فعلوه لك' },
        { id: 'patience', title: 'تحدي الصبر', icon: '🌿', task: 'تحمّل موقفاً صعباً دون شكوى' }
    ];
    const user = JSON.parse(localStorage.getItem('noorUser') || '{}');
    const completed = user.completedChallenges || [];
    document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;"><span style="font-size: 4rem;">🏆</span><h2>التحديات اليومية</h2><p style="color: var(--text-secondary);">50 نقطة لكل تحدي</p></div>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
            ${challenges.map(c => `<div style="background: var(--bg-dark); border: 1px solid ${completed.includes(c.id) ? 'var(--success)' : 'var(--border)'}; padding: 1.5rem; border-radius: 12px;">
                <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;"><span style="font-size: 2rem;">${c.icon}</span><div><h4>${c.title}</h4><p style="color: var(--text-secondary); font-size: 0.9rem;">${c.task}</p></div></div>
                ${completed.includes(c.id) ? '<span style="color: var(--success);">✅ مكتمل</span>' : `<button onclick="completeChallenge('${c.id}'); showChallengesPage();" class="btn-primary" style="width: 100%;">أكملت التحدي ✓</button>`}
            </div>`).join('')}
        </div>
    </div>`;
    document.getElementById('valueModal').classList.add('active');
}

function showGamesPage() {
    document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;"><span style="font-size: 4rem;">🎮</span><h2>الألعاب التعليمية</h2></div>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
            <button onclick="playMatchGame()" style="background: var(--bg-dark); border: 1px solid var(--border); color: var(--text-primary); padding: 1.5rem; border-radius: 12px; cursor: pointer; font-family: inherit; text-align: right;"><span style="font-size: 2rem; display: block; margin-bottom: 0.5rem;">🔗</span><h4>مطابقة الكلمات</h4><p style="color: var(--text-secondary); font-size: 0.9rem;">طابق القيمة مع معناها</p></button>
            <button onclick="playTrueFalse()" style="background: var(--bg-dark); border: 1px solid var(--border); color: var(--text-primary); padding: 1.5rem; border-radius: 12px; cursor: pointer; font-family: inherit; text-align: right;"><span style="font-size: 2rem; display: block; margin-bottom: 0.5rem;">✅</span><h4>صح أم خطأ</h4><p style="color: var(--text-secondary); font-size: 0.9rem;">حدد صحة العبارات</p></button>
        </div>
    </div>`;
    document.getElementById('valueModal').classList.add('active');
}

function playMatchGame() {
    const pairs = [{value:'الصدق',meaning:'قول الحق'},{value:'الأمانة',meaning:'حفظ الحقوق'},{value:'الشكر',meaning:'حمد النعم'},{value:'الصبر',meaning:'التحمل'}];
    let selected = null, matches = 0;
    const sv = [...pairs].sort(() => Math.random() - 0.5), sm = [...pairs].sort(() => Math.random() - 0.5);
    function render() {
        document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
            <button class="modal-close" onclick="closeModal()">×</button>
            <div style="text-align: center; margin-bottom: 2rem;"><h3>طابق القيمة مع معناها</h3><p style="color: var(--text-secondary);">${matches}/${pairs.length}</p></div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">${sv.map((p, i) => `<button id="v${i}" onclick="selectValue(${i})" style="background: var(--bg-dark); border: 2px solid var(--border); color: var(--text-primary); padding: 1rem; border-radius: 8px; cursor: pointer; font-family: inherit;">${p.value}</button>`).join('')}</div>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">${sm.map((p, i) => `<button id="m${i}" onclick="selectMeaning(${i})" style="background: var(--bg-dark); border: 2px solid var(--border); color: var(--text-primary); padding: 1rem; border-radius: 8px; cursor: pointer; font-family: inherit;">${p.meaning}</button>`).join('')}</div>
            </div>
        </div>`;
    }
    window.selectValue = function(i) { selected = {type:'value',index:i,data:sv[i]}; document.querySelectorAll('[id^="v"]').forEach(b => b.style.borderColor = 'var(--border)'); document.getElementById('v'+i).style.borderColor = 'var(--primary)'; };
    window.selectMeaning = function(i) {
        if (!selected || selected.type !== 'value') return;
        if (selected.data.meaning === sm[i].meaning) {
            document.getElementById('v'+selected.index).style.borderColor = 'var(--success)'; document.getElementById('v'+selected.index).disabled = true;
            document.getElementById('m'+i).style.borderColor = 'var(--success)'; document.getElementById('m'+i).disabled = true;
            matches++;
            if (matches === pairs.length) { addPoints(30); setTimeout(() => { document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem; text-align: center;"><button class="modal-close" onclick="closeModal()">×</button><div style="font-size: 5rem;">🏆</div><h2>أحسنت!</h2><p style="color: var(--accent);">+ 30 نقطة</p><button class="btn-primary" onclick="showGamesPage()" style="width: 100%; margin-top: 1rem;">العودة للألعاب</button></div>`; createConfetti(); }, 500); }
        } else { document.getElementById('m'+i).style.borderColor = 'var(--danger)'; setTimeout(() => document.getElementById('m'+i).style.borderColor = 'var(--border)', 500); }
        selected = null; document.querySelectorAll('[id^="v"]:not(:disabled)').forEach(b => b.style.borderColor = 'var(--border)');
    };
    render();
}

function playTrueFalse() {
    const statements = [{text:'الصدق يهدي إلى البر',answer:true},{text:'الكذب من صفات المؤمنين',answer:false},{text:'التعاون على الإثم مطلوب',answer:false},{text:'الصبر من صفات الأقوياء',answer:true},{text:'الشكر يزيد النعم',answer:true}];
    let current = 0, score = 0;
    function showS() {
        const s = statements[current];
        document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
            <button class="modal-close" onclick="closeModal()">×</button>
            <div style="text-align: center; margin-bottom: 2rem;"><h3>صح أم خطأ؟</h3><p style="color: var(--text-secondary);">${current + 1}/${statements.length}</p></div>
            <div style="background: var(--bg-dark); padding: 2rem; border-radius: 12px; margin-bottom: 2rem; text-align: center;"><p style="font-size: 1.2rem;">${s.text}</p></div>
            <div style="display: flex; gap: 1rem;"><button onclick="tfAnswer(true)" class="btn-primary" style="flex: 1; background: var(--success);">✓ صح</button><button onclick="tfAnswer(false)" class="btn-primary" style="flex: 1; background: var(--danger);">✗ خطأ</button></div>
        </div>`;
    }
    window.tfAnswer = function(ans) {
        if (ans === statements[current].answer) score++;
        current++;
        if (current < statements.length) showS();
        else { addPoints(score * 5); document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem; text-align: center;"><button class="modal-close" onclick="closeModal()">×</button><div style="font-size: 5rem;">${score >= 4 ? '🏆' : '⭐'}</div><h2>${score >= 4 ? 'ممتاز!' : 'أحسنت!'}</h2><p style="color: var(--text-secondary);">${score}/${statements.length}</p><p style="color: var(--accent);">+ ${score * 5} نقطة</p><button class="btn-primary" onclick="showGamesPage()" style="width: 100%; margin-top: 1rem;">العودة للألعاب</button></div>`; if (score >= 4) createConfetti(); }
    };
    showS();
}
