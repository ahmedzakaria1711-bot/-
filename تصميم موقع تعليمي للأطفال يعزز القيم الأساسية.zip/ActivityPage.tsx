import { useState, useMemo } from "react";
import { useRoute, Link } from "wouter";
import { valuesData, Activity, StageContent } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { 
  CheckCircle2, 
  Circle, 
  ArrowRight, 
  School, 
  Home, 
  Laptop, 
  ScrollText, 
  GraduationCap, 
  Sparkles,
  Presentation,
  MessageCircle,
  HelpCircle,
  Play,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Footer } from "@/components/Footer";
import { useStudent } from "@/contexts/StudentContext";
import { PresentationViewer } from "@/components/PresentationViewer";
import { ChatBot, ChatBotTrigger } from "@/components/ChatBot";
import { InteractiveQuiz } from "@/components/InteractiveQuiz";
import { interactiveContentMap } from "@/lib/interactiveContent";
import { motion, AnimatePresence } from "framer-motion";

type ActiveModal = "presentation" | "quiz" | null;

export default function ActivityPage() {
  const { currentStudent } = useStudent();
  const [match, params] = useRoute("/activity/:id");
  const valueId = match ? params.id : null;
  const value = valuesData.find((v) => v.id === valueId);

  // تحديد المحتوى حسب المرحلة الدراسية
  const stageContent = useMemo(() => {
    if (!value) return null;
    // تحديد المرحلة من الصف الدراسي
    const grade = currentStudent?.grade || "";
    const isElementary = grade.includes("الابتدائي");
    const isMiddle = grade.includes("المتوسط");
    
    if (isElementary && value.elementaryContent) {
      return value.elementaryContent;
    } else if (isMiddle && value.middleContent) {
      return value.middleContent;
    }
    return null;
  }, [value, currentStudent?.grade]);

  // استخدام المحتوى المخصص أو الافتراضي
  const description = stageContent?.description || value?.description || "";
  const initialActivities = stageContent?.activities || value?.activities || [];
  const evidence = stageContent?.evidence || value?.evidence || { positive: [], needsSupport: [] };
  const teacherTips = stageContent?.teacherTips || value?.teacherTips || "";

  // Local state to handle activity completion simulation
  const [activities, setActivities] = useState<Activity[]>(initialActivities);
  
  // حالة المكونات التفاعلية
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);

  // الحصول على المحتوى التفاعلي
  const interactiveContent = valueId ? interactiveContentMap[valueId] : null;

  const guideImage = currentStudent?.gender === "girl" ? "/images/guide-girl.png" : "/images/guide-boy.png";
  const guideTip = currentStudent?.gender === "girl" 
    ? `أحسنتِ يا بطلة! أكملي الأنشطة لتصبحي نجمة في قيمة ${value?.title}`
    : `أحسنت يا بطل! أكمل الأنشطة لتصبح نجماً في قيمة ${value?.title}`;

  if (!value) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FDFBF7]">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-muted-foreground mb-4">القيمة غير موجودة</h2>
          <Link href="/">
            <Button>العودة للرئيسية</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleToggleActivity = (activityId: string) => {
    setActivities((prev) =>
      prev.map((act) => {
        if (act.id === activityId) {
          const newStatus = act.status === "completed" ? "pending" : "completed";
          if (newStatus === "completed") {
            toast.success("أحسنت! تم إنجاز النشاط بنجاح 🎉");
          }
          return { ...act, status: newStatus };
        }
        return act;
      })
    );
  };

  const getActivityIcon = (type: Activity["type"]) => {
    switch (type) {
      case "صفّي": return <School className="w-5 h-5" />;
      case "منزلي": return <Home className="w-5 h-5" />;
      case "رقمي": return <Laptop className="w-5 h-5" />;
    }
  };

  const Icon = value.icon;

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20">
      {/* Header Image */}
      <div className="h-[200px] w-full relative overflow-hidden">
        <img 
          src="/images/hero-activities.png" 
          alt="Activities" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/10" />
        <Link href="/">
          <Button variant="secondary" size="icon" className="absolute top-6 right-6 rounded-full shadow-lg z-10">
            <ArrowRight className="w-5 h-5" />
          </Button>
        </Link>
      </div>

      <main className="container mx-auto px-4 -mt-16 relative z-10">
        {/* Value Header Card */}
        <div className="bg-white rounded-3xl shadow-xl p-6 mb-8 text-center border-b-4 border-muted">
          <div className={cn("w-20 h-20 mx-auto rounded-2xl flex items-center justify-center mb-4 shadow-inner", value.color)}>
            <Icon className="w-10 h-10" />
          </div>
          <h1 className="text-3xl font-extrabold text-foreground mb-2">{value.title}</h1>
          <p className="text-muted-foreground max-w-xl mx-auto text-lg">{description}</p>
          
          {/* مؤشر المرحلة الدراسية */}
          {currentStudent?.grade && (
            <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-sky-50 to-sky-100 border border-sky-200">
              <Sparkles className="w-4 h-4 text-sky-500" />
              <span className="text-sm font-medium text-sky-700">محتوى المرحلة الابتدائية</span>
            </div>
          )}
        </div>

        {/* أزرار المحتوى التفاعلي */}
        {interactiveContent && (
          <div className="max-w-3xl mx-auto mb-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <span className="bg-gradient-to-r from-purple-500 to-pink-500 w-2 h-8 rounded-full block"></span>
              المحتوى التفاعلي
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* زر العرض التقديمي */}
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setActiveModal("presentation")}
                className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Presentation className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-lg mb-1">العرض التقديمي</h3>
                <p className="text-sm text-white/80">15 شريحة تعليمية</p>
                <div className="mt-3 flex items-center justify-center gap-2 text-sm">
                  <Play className="w-4 h-4" />
                  ابدأ المشاهدة
                </div>
              </motion.button>

              {/* زر الاختبار التفاعلي */}
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setActiveModal("quiz")}
                className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <HelpCircle className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-lg mb-1">الاختبار التفاعلي</h3>
                <p className="text-sm text-white/80">5 أسئلة متنوعة</p>
                <div className="mt-3 flex items-center justify-center gap-2 text-sm">
                  <Play className="w-4 h-4" />
                  ابدأ الاختبار
                </div>
              </motion.button>

              {/* زر الروبوت */}
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setIsChatOpen(true)}
                className="bg-gradient-to-br from-purple-500 to-pink-600 text-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-lg mb-1">روبوت {value.title}</h3>
                <p className="text-sm text-white/80">تحدث واسأل</p>
                <div className="mt-3 flex items-center justify-center gap-2 text-sm">
                  <Play className="w-4 h-4" />
                  ابدأ المحادثة
                </div>
              </motion.button>
            </div>
          </div>
        )}

        {/* الشواهد الشرعية */}
        {value.islamicEvidence && value.islamicEvidence.length > 0 && (
          <div className="max-w-3xl mx-auto mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            {value.islamicEvidence.map((ev, index) => (
              <div key={index} className="bg-white rounded-2xl p-6 shadow-sm border border-amber-100 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-2 h-full bg-amber-400" />
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-amber-50 flex items-center justify-center shrink-0">
                    <ScrollText className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-amber-800 mb-2">
                      {ev.type === "quran" ? "من القرآن الكريم" : "من السنة النبوية"}
                    </h4>
                    <p className="text-lg text-gray-700 font-medium leading-relaxed mb-2 font-serif">
                      "{ev.text}"
                    </p>
                    <span className="text-sm text-amber-600 font-semibold block text-left pl-4">
                      — {ev.source}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Activities List */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <span className="bg-secondary w-2 h-8 rounded-full block"></span>
            أنشطة القيمة
          </h2>

          <div className="space-y-4">
            {activities.map((activity) => (
              <div 
                key={activity.id} 
                className={cn(
                  "group bg-white rounded-2xl p-5 shadow-sm border-2 transition-all duration-300 hover:shadow-md hover:scale-[1.01]",
                  activity.status === "completed" ? "border-green-100 bg-green-50/30" : "border-transparent"
                )}
              >
                <div className="flex items-start gap-4">
                  <div className={cn(
                    "p-3 rounded-xl shrink-0",
                    activity.type === "صفّي" ? "bg-orange-100 text-orange-600" :
                    activity.type === "منزلي" ? "bg-purple-100 text-purple-600" :
                    "bg-blue-100 text-blue-600"
                  )}>
                    {getActivityIcon(activity.type)}
                  </div>
                  
                  <div className="flex-grow">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-gray-100 text-gray-500">
                        {activity.type}
                      </span>
                      <h3 className={cn("font-bold text-lg", activity.status === "completed" && "text-muted-foreground line-through decoration-2 decoration-green-300")}>
                        {activity.title}
                      </h3>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {activity.description}
                    </p>
                  </div>

                  <Button
                    onClick={() => handleToggleActivity(activity.id)}
                    variant={activity.status === "completed" ? "default" : "outline"}
                    className={cn(
                      "shrink-0 rounded-xl h-12 w-12 p-0 transition-all duration-500",
                      activity.status === "completed" 
                        ? "bg-green-500 hover:bg-green-600 text-white shadow-green-200 shadow-lg rotate-0" 
                        : "hover:bg-gray-50 text-gray-300 hover:text-gray-400 rotate-180"
                    )}
                  >
                    {activity.status === "completed" ? (
                      <CheckCircle2 className="w-6 h-6" />
                    ) : (
                      <Circle className="w-6 h-6" />
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Evidence Section Preview */}
        <div className="max-w-3xl mx-auto mt-12 bg-blue-50 rounded-3xl p-6 border border-blue-100 relative">
          {/* الشخصية المرشدة */}
          <div className="absolute -top-20 -left-10 hidden lg:block w-40 h-40">
             <img src={guideImage} alt="Guide" className="w-full h-full object-contain drop-shadow-lg animate-bounce-slow" />
             <div className="absolute top-0 right-full mr-2 bg-white p-3 rounded-xl rounded-tr-none shadow-md w-48 text-xs font-bold text-primary">
               {guideTip}
             </div>
          </div>

          <h3 className="font-bold text-blue-800 mb-4 text-lg">شواهد التقييم المتوقعة</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-xl shadow-sm">
              <h4 className="font-bold text-green-600 text-sm mb-2">👍 سلوكيات إيجابية</h4>
              <ul className="space-y-2">
                {evidence.positive.map((e, i) => (
                  <li key={i} className="text-sm text-gray-600 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400" />
                    {e}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-sm">
              <h4 className="font-bold text-orange-500 text-sm mb-2">💪 بحاجة لدعم</h4>
              <ul className="space-y-2">
                {evidence.needsSupport.map((e, i) => (
                  <li key={i} className="text-sm text-gray-600 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-orange-300" />
                    {e}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Modal للعرض التقديمي */}
      <AnimatePresence>
        {activeModal === "presentation" && interactiveContent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setActiveModal(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-4xl max-h-[90vh] overflow-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative">
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute -top-2 -left-2 z-10 rounded-full shadow-lg"
                  onClick={() => setActiveModal(null)}
                >
                  <X className="w-5 h-5" />
                </Button>
                <PresentationViewer
                  slides={interactiveContent.slides}
                  valueTitle={value.title}
                  valueColor={value.color}
                  onComplete={() => {
                    toast.success("أحسنت! أكملت العرض التقديمي 🎉");
                    setActiveModal(null);
                  }}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modal للاختبار */}
      <AnimatePresence>
        {activeModal === "quiz" && interactiveContent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setActiveModal(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-2xl max-h-[90vh] overflow-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative">
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute -top-2 -left-2 z-10 rounded-full shadow-lg"
                  onClick={() => setActiveModal(null)}
                >
                  <X className="w-5 h-5" />
                </Button>
                <InteractiveQuiz
                  questions={interactiveContent.quizQuestions}
                  valueTitle={value.title}
                  valueColor={value.color}
                  onComplete={(score) => {
                    toast.success(`أحسنت! حصلت على ${score} من ${interactiveContent.quizQuestions.length} 🎉`);
                  }}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* روبوت المحادثة */}
      {interactiveContent && (
        <>
          {!isChatOpen && (
            <ChatBotTrigger onClick={() => setIsChatOpen(true)} valueColor={value.color} />
          )}
          <ChatBot
            valueTitle={value.title}
            valueColor={value.color}
            botResponses={interactiveContent.botResponses}
            isOpen={isChatOpen}
            onClose={() => setIsChatOpen(false)}
          />
        </>
      )}

      <Footer />
    </div>
  );
}
