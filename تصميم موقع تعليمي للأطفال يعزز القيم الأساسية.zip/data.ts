
export type ActivityStatus = "pending" | "completed";
export type EvaluationLevel = "ناشئ" | "نامي" | "ثابت" | "متميّز";
export type ValueCategory = "faith" | "social" | "personal";

export interface Activity {
  id: string;
  title: string;
  type: "صفّي" | "منزلي" | "رقمي";
  description: string;
  status: ActivityStatus;
}

export interface IslamicEvidence {
  type: "quran" | "hadith";
  text: string;
  source: string;
}

export interface StageContent {
  description: string;
  activities: Activity[];
  evidence: {
    positive: string[];
    needsSupport: string[];
  };
  teacherTips: string;
}

// شريحة عرض تقديمي
export interface Slide {
  id: number;
  title: string;
  content: string;
  type: "intro" | "definition" | "evidence" | "story" | "activity" | "summary" | "quiz";
  image?: string;
  bulletPoints?: string[];
}

// سؤال تفاعلي
export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number; // index of correct option
  explanation: string;
}

// رسالة الروبوت
export interface BotMessage {
  role: "bot" | "user";
  content: string;
}

// محتوى القيمة التفاعلي
export interface ValueInteractiveContent {
  slides: Slide[];
  quizQuestions: QuizQuestion[];
  botResponses: {
    greeting: string;
    encouragement: string[];
    hints: string[];
    completion: string;
  };
}

export interface Value {
  id: string;
  title: string;
  icon: any;
  color: string; // Tailwind class for text/bg
  description: string;
  category: ValueCategory;
  progress: number;
  level: EvaluationLevel;
  activities: Activity[];
  evidence: {
    positive: string[];
    needsSupport: string[];
  };
  islamicEvidence: IslamicEvidence[];
  teacherTips: string;
  // محتوى مخصص حسب المرحلة
  elementaryContent?: StageContent;
  middleContent?: StageContent;
  // المحتوى التفاعلي (عرض تقديمي + أسئلة + روبوت)
  interactiveContent?: ValueInteractiveContent;
}

export const valuesData: Value[] = [
  // --- قيم إيمانية (Faith) ---
  {
    id: "sincerity",
    title: "الإخلاص",
    icon: Heart,
    color: "text-red-500 bg-red-100",
    description: "العمل بصدق ونية صافية لوجه الله",
    category: "faith",
    progress: 0,