import { createContext, useContext, useState, ReactNode } from "react";
import { trpc } from "@/lib/trpc";

interface Student {
  id: number;
  name: string;
  email: string;
  grade: string;
  gender: "boy" | "girl";
  points: number;
  totalProgress: number;
  achievements: string[];
}

interface StudentContextType {
  currentStudent: Student | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: { name: string; email: string; password: string; grade: string; gender: "boy" | "girl" }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  addAchievement: (achievementId: string) => Promise<void>;
  refreshStudent: () => Promise<void>;
}

const StudentContext = createContext<StudentContextType | undefined>(undefined);

export function StudentProvider({ children }: { children: ReactNode }) {
  const [currentStudent, setCurrentStudent] = useState<Student | null>(() => {
    const saved = localStorage.getItem("currentStudent");
    return saved ? JSON.parse(saved) : null;
  });
  const [isLoading, setIsLoading] = useState(false);

  const loginMutation = trpc.student.login.useMutation();
  const registerMutation = trpc.student.register.useMutation();
  const addAchievementMutation = trpc.student.addAchievement.useMutation();
  const getStudentQuery = trpc.student.getById.useQuery(
    { id: currentStudent?.id || 0 },
    { enabled: false }
  );

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const result = await loginMutation.mutateAsync({ email, password });
      if (result.success && result.student) {
        const student: Student = {
          id: result.student.id,
          name: result.student.name,
          email: result.student.email || "",
          grade: result.student.grade,
          gender: result.student.gender,
          points: result.student.points,
          totalProgress: result.student.totalProgress,
          achievements: result.student.achievements || [],
        };
        setCurrentStudent(student);
        localStorage.setItem("currentStudent", JSON.stringify(student));
        return { success: true };
      }
      return { success: false, error: "فشل تسجيل الدخول" };
    } catch (error: any) {
      return { success: false, error: error.message || "فشل تسجيل الدخول" };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: { name: string; email: string; password: string; grade: string; gender: "boy" | "girl" }) => {
    setIsLoading(true);
    try {
      const result = await registerMutation.mutateAsync(data);
      if (result.success && result.studentId) {
        // Auto login after registration
        return await login(data.email, data.password);
      }
      return { success: false, error: "فشل إنشاء الحساب" };
    } catch (error: any) {
      return { success: false, error: error.message || "فشل إنشاء الحساب" };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentStudent(null);
    localStorage.removeItem("currentStudent");
  };

  const addAchievement = async (achievementId: string) => {
    if (!currentStudent) return;
    try {
      const result = await addAchievementMutation.mutateAsync({
        studentId: currentStudent.id,
        achievementId,
      });
      if (result.success) {
        const updatedStudent = { ...currentStudent, achievements: result.achievements };
        setCurrentStudent(updatedStudent);
        localStorage.setItem("currentStudent", JSON.stringify(updatedStudent));
      }
    } catch (error) {
      console.error("Failed to add achievement:", error);
    }
  };

  const refreshStudent = async () => {
    if (!currentStudent) return;
    try {
      const result = await getStudentQuery.refetch();
      if (result.data) {
        const student: Student = {
          id: result.data.id,
          name: result.data.name,
          email: result.data.email || "",
          grade: result.data.grade,
          gender: result.data.gender,
          points: result.data.points,
          totalProgress: result.data.totalProgress,
          achievements: result.data.achievements || [],
        };
        setCurrentStudent(student);
        localStorage.setItem("currentStudent", JSON.stringify(student));
      }
    } catch (error) {
      console.error("Failed to refresh student:", error);
    }
  };

  return (
    <StudentContext.Provider value={{ 
      currentStudent, 
      isLoading, 
      login, 
      register, 
      logout, 
      addAchievement,
      refreshStudent 
    }}>
      {children}
    </StudentContext.Provider>
  );
}

export function useStudent() {
  const context = useContext(StudentContext);
  if (context === undefined) {
    throw new Error("useStudent must be used within a StudentProvider");
  }
  return context;
}
