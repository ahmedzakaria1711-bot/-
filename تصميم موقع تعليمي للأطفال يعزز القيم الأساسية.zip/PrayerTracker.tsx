import { useState, useEffect, useRef } from "react";
import { Check, RotateCcw, Download, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStudent } from "@/contexts/StudentContext";
import { toast } from "sonner";

const prayers = [
  { id: "fajr", name: "الفجر", icon: "🌅" },
  { id: "dhuhr", name: "الظهر", icon: "☀️" },
  { id: "asr", name: "العصر", icon: "🌤️" },
  { id: "maghrib", name: "المغرب", icon: "🌅" },
  { id: "isha", name: "العشاء", icon: "🌙" },
];

const days = [
  { id: "saturday", name: "السبت" },
  { id: "sunday", name: "الأحد" },
  { id: "monday", name: "الإثنين" },
  { id: "tuesday", name: "الثلاثاء" },
  { id: "wednesday", name: "الأربعاء" },
  { id: "thursday", name: "الخميس" },
  { id: "friday", name: "الجمعة" },
];

type PrayerData = {
  [day: string]: {
    [prayer: string]: boolean;
  };
};

const getWeekKey = () => {
  const now = new Date();
  const startOfYear = new Date(now.getFullYear(), 0, 1);
  const weekNumber = Math.ceil(((now.getTime() - startOfYear.getTime()) / 86400000 + startOfYear.getDay() + 1) / 7);
  return `prayer_tracker_${now.getFullYear()}_week_${weekNumber}`;
};

const getWeekDates = () => {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const saturday = new Date(now);
  saturday.setDate(now.getDate() - ((dayOfWeek + 1) % 7));
  
  const friday = new Date(saturday);
  friday.setDate(saturday.getDate() + 6);
  
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('ar-SA', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };
  
  return {
    start: formatDate(saturday),
    end: formatDate(friday),
    today: formatDate(now)
  };
};

export function PrayerTracker() {
  const { currentStudent } = useStudent();
  const [prayerData, setPrayerData] = useState<PrayerData>({});
  const [weekKey, setWeekKey] = useState(getWeekKey());
  const tableRef = useRef<HTMLDivElement>(null);
  const weekDates = getWeekDates();

  // تحميل البيانات من localStorage
  useEffect(() => {
    const currentWeekKey = getWeekKey();
    setWeekKey(currentWeekKey);
    
    const studentKey = currentStudent?.email || "guest";
    const storageKey = `${currentWeekKey}_${studentKey}`;
    const saved = localStorage.getItem(storageKey);
    
    if (saved) {
      setPrayerData(JSON.parse(saved));
    } else {
      // تهيئة جدول فارغ
      const initialData: PrayerData = {};
      days.forEach(day => {
        initialData[day.id] = {};
        prayers.forEach(prayer => {
          initialData[day.id][prayer.id] = false;
        });
      });
      setPrayerData(initialData);
    }
  }, [currentStudent]);

  // حفظ البيانات في localStorage
  useEffect(() => {
    if (Object.keys(prayerData).length > 0) {
      const studentKey = currentStudent?.email || "guest";
      const storageKey = `${weekKey}_${studentKey}`;
      localStorage.setItem(storageKey, JSON.stringify(prayerData));
    }
  }, [prayerData, weekKey, currentStudent]);

  const togglePrayer = (dayId: string, prayerId: string) => {
    setPrayerData(prev => ({
      ...prev,
      [dayId]: {
        ...prev[dayId],
        [prayerId]: !prev[dayId]?.[prayerId]
      }
    }));
  };

  const resetWeek = () => {
    const initialData: PrayerData = {};
    days.forEach(day => {
      initialData[day.id] = {};
      prayers.forEach(prayer => {
        initialData[day.id][prayer.id] = false;
      });
    });
    setPrayerData(initialData);
    toast.success("تم مسح جدول الصلوات لهذا الأسبوع");
  };

  // حساب الإحصائيات
  const totalPrayers = days.length * prayers.length;
  const completedPrayers = Object.values(prayerData).reduce((acc, day) => {
    return acc + Object.values(day).filter(Boolean).length;
  }, 0);
  const percentage = Math.round((completedPrayers / totalPrayers) * 100);

  // طباعة الجدول
  const handlePrint = () => {
    const printContent = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <title>جدول متابعة الصلوات - ${currentStudent?.name || "الطالب"}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&display=swap');
          * { font-family: 'Almarai', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
          body { padding: 20px; background: white; }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #10b981; padding-bottom: 20px; }
          .header h1 { color: #065f46; font-size: 28px; margin-bottom: 10px; }
          .header .mosque { font-size: 50px; }
          .info { display: flex; justify-content: space-between; margin-bottom: 20px; background: #f0fdf4; padding: 15px; border-radius: 10px; }
          .info div { text-align: center; }
          .info label { font-size: 12px; color: #6b7280; display: block; }
          .info span { font-size: 16px; font-weight: bold; color: #065f46; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          th, td { border: 2px solid #d1fae5; padding: 12px; text-align: center; }
          th { background: #10b981; color: white; font-size: 14px; }
          th .icon { font-size: 20px; display: block; margin-bottom: 5px; }
          td:first-child { background: #f0fdf4; font-weight: bold; color: #065f46; }
          .checkbox { width: 30px; height: 30px; border: 2px solid #10b981; border-radius: 50%; display: inline-block; }
          .checkbox.checked { background: #10b981; position: relative; }
          .checkbox.checked::after { content: "✓"; color: white; font-size: 18px; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); }
          .stats { background: #f0fdf4; padding: 20px; border-radius: 10px; text-align: center; }
          .stats h3 { color: #065f46; margin-bottom: 10px; }
          .progress-bar { height: 20px; background: #d1fae5; border-radius: 10px; overflow: hidden; margin: 10px 0; }
          .progress-fill { height: 100%; background: linear-gradient(to left, #10b981, #14b8a6); border-radius: 10px; }
          .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 12px; }
          @media print { body { print-color-adjust: exact; -webkit-print-color-adjust: exact; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="mosque">🕌</div>
          <h1>جدول متابعة الصلوات الأسبوعي</h1>
        </div>
        
        <div class="info">
          <div>
            <label>اسم الطالب/ة</label>
            <span>${currentStudent?.name || "---"}</span>
          </div>
          <div>
            <label>الصف</label>
            <span>${currentStudent?.grade || "---"}</span>
          </div>
          <div>
            <label>من تاريخ</label>
            <span>${weekDates.start}</span>
          </div>
          <div>
            <label>إلى تاريخ</label>
            <span>${weekDates.end}</span>
          </div>
        </div>
        
        <table>
          <thead>
            <tr>
              <th>اليوم</th>
              ${prayers.map(p => `<th><span class="icon">${p.icon}</span>${p.name}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${days.map(day => `
              <tr>
                <td>${day.name}</td>
                ${prayers.map(prayer => `
                  <td>
                    <div class="checkbox ${prayerData[day.id]?.[prayer.id] ? 'checked' : ''}"></div>
                  </td>
                `).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="stats">
          <h3>إحصائيات الأسبوع</h3>
          <div class="progress-bar">
            <div class="progress-fill" style="width: ${percentage}%"></div>
          </div>
          <p>أديت <strong>${completedPrayers}</strong> صلاة من أصل <strong>${totalPrayers}</strong> صلاة (${percentage}%)</p>
        </div>
        
        <div class="footer">
          <p>منصة قِيَمي - مدارس مدينة العلوم العالمية</p>
          <p>تاريخ الطباعة: ${weekDates.today}</p>
        </div>
      </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.onload = () => {
        printWindow.print();
      };
    }
  };

  // تنزيل كصورة
  const handleDownload = async () => {
    try {
      // إنشاء canvas للتنزيل
      const printContent = `
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
          <meta charset="UTF-8">
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&display=swap');
            * { font-family: 'Almarai', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
            body { padding: 20px; background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); width: 800px; }
            .header { text-align: center; margin-bottom: 20px; }
            .header h1 { color: #065f46; font-size: 24px; }
            .header .mosque { font-size: 40px; }
            .info { display: flex; justify-content: space-around; margin-bottom: 15px; background: white; padding: 10px; border-radius: 10px; }
            .info div { text-align: center; }
            .info label { font-size: 10px; color: #6b7280; display: block; }
            .info span { font-size: 14px; font-weight: bold; color: #065f46; }
            table { width: 100%; border-collapse: collapse; background: white; border-radius: 10px; overflow: hidden; }
            th, td { border: 1px solid #d1fae5; padding: 8px; text-align: center; }
            th { background: #10b981; color: white; font-size: 12px; }
            td:first-child { background: #f0fdf4; font-weight: bold; color: #065f46; font-size: 12px; }
            .check { color: #10b981; font-size: 20px; }
            .footer { text-align: center; margin-top: 15px; color: #065f46; font-size: 10px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="mosque">🕌</div>
            <h1>جدول متابعة الصلوات</h1>
          </div>
          <div class="info">
            <div><label>الطالب/ة</label><span>${currentStudent?.name || "---"}</span></div>
            <div><label>الصف</label><span>${currentStudent?.grade || "---"}</span></div>
            <div><label>الأسبوع</label><span>${weekDates.start} - ${weekDates.end}</span></div>
          </div>
          <table>
            <tr><th>اليوم</th>${prayers.map(p => `<th>${p.icon} ${p.name}</th>`).join('')}</tr>
            ${days.map(day => `<tr><td>${day.name}</td>${prayers.map(prayer => `<td>${prayerData[day.id]?.[prayer.id] ? '<span class="check">✓</span>' : '○'}</td>`).join('')}</tr>`).join('')}
          </table>
          <div class="footer">منصة قِيَمي - ${weekDates.today}</div>
        </body>
        </html>
      `;
      
      // فتح نافذة للطباعة/الحفظ
      const downloadWindow = window.open('', '_blank');
      if (downloadWindow) {
        downloadWindow.document.write(printContent);
        downloadWindow.document.close();
        toast.success("تم فتح الجدول - يمكنك حفظه كـ PDF من خيارات الطباعة");
        setTimeout(() => {
          downloadWindow.print();
        }, 500);
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء التنزيل");
    }
  };

  return (
    <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-3xl p-6 border-2 border-emerald-100 shadow-lg" ref={tableRef}>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <span className="text-4xl">🕌</span>
          <div>
            <h3 className="text-2xl font-bold text-emerald-800">جدول متابعة الصلوات</h3>
            <p className="text-sm text-emerald-600">الأسبوع: {weekDates.start} - {weekDates.end}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handlePrint}
            className="text-emerald-700 border-emerald-300 hover:bg-emerald-100"
          >
            <Printer className="w-4 h-4 ml-2" />
            طباعة
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleDownload}
            className="text-emerald-700 border-emerald-300 hover:bg-emerald-100"
          >
            <Download className="w-4 h-4 ml-2" />
            تنزيل
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={resetWeek}
            className="text-red-600 border-red-200 hover:bg-red-50"
          >
            <RotateCcw className="w-4 h-4 ml-2" />
            مسح
          </Button>
        </div>
      </div>

      {/* معلومات الطالب */}
      {currentStudent && (
        <div className="mb-4 bg-white/60 rounded-xl p-3 flex flex-wrap justify-center gap-6 text-sm">
          <div className="text-center">
            <span className="text-emerald-600">الطالب/ة: </span>
            <span className="font-bold text-emerald-800">{currentStudent.name}</span>
          </div>
          <div className="text-center">
            <span className="text-emerald-600">الصف: </span>
            <span className="font-bold text-emerald-800">{currentStudent.grade}</span>
          </div>
          <div className="text-center">
            <span className="text-emerald-600">اليوم: </span>
            <span className="font-bold text-emerald-800">{weekDates.today}</span>
          </div>
        </div>
      )}

      {/* شريط التقدم */}
      <div className="mb-6 bg-white/50 rounded-xl p-4">
        <div className="flex justify-between text-sm mb-2">
          <span className="font-medium text-emerald-700">تقدمك هذا الأسبوع</span>
          <span className="font-bold text-emerald-800">{completedPrayers} / {totalPrayers} صلاة</span>
        </div>
        <div className="h-4 bg-emerald-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 transition-all duration-500 rounded-full"
            style={{ width: `${percentage}%` }}
          />
        </div>
        <p className="text-center mt-2 text-emerald-600 font-medium">
          {percentage === 100 ? "🎉 ماشاء الله! أكملت جميع صلواتك" : 
           percentage >= 70 ? "👏 أحسنت! استمر" : 
           percentage >= 40 ? "💪 جيد، واصل المحافظة" : 
           "🌟 ابدأ بتسجيل صلواتك"}
        </p>
      </div>

      {/* جدول الصلوات */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr>
              <th className="p-2 text-right text-emerald-700 font-bold">اليوم</th>
              {prayers.map(prayer => (
                <th key={prayer.id} className="p-2 text-center">
                  <div className="flex flex-col items-center gap-1">
                    <span className="text-xl">{prayer.icon}</span>
                    <span className="text-xs font-bold text-emerald-700">{prayer.name}</span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {days.map(day => (
              <tr key={day.id} className="border-t border-emerald-100">
                <td className="p-2 font-bold text-emerald-800">{day.name}</td>
                {prayers.map(prayer => (
                  <td key={prayer.id} className="p-2 text-center">
                    <button
                      onClick={() => togglePrayer(day.id, prayer.id)}
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                        prayerData[day.id]?.[prayer.id]
                          ? "bg-emerald-500 text-white shadow-lg scale-110"
                          : "bg-white border-2 border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50"
                      }`}
                    >
                      {prayerData[day.id]?.[prayer.id] && <Check className="w-5 h-5" />}
                    </button>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="text-center text-xs text-emerald-600 mt-4">
        💡 يتم مسح الجدول تلقائياً كل أسبوع جديد
      </p>
    </div>
  );
}
