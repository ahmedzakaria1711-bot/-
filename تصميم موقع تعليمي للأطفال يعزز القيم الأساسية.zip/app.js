// بيانات القيم
const valuesData = [
    { id: 'honesty', name: 'الصدق', icon: '🎯', description: 'قول الحق والابتعاد عن الكذب', category: 'faith', verse: 'يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَكُونُوا مَعَ الصَّادِقِينَ', verseSource: 'التوبة: 119', hadith: 'عليكم بالصدق، فإن الصدق يهدي إلى البر', hadithSource: 'متفق عليه' },
    { id: 'trust', name: 'الأمانة', icon: '🔐', description: 'حفظ الحقوق وأداؤها لأصحابها', category: 'social', verse: 'إِنَّ اللَّهَ يَأْمُرُكُمْ أَن تُؤَدُّوا الْأَمَانَاتِ إِلَىٰ أَهْلِهَا', verseSource: 'النساء: 58', hadith: 'أدِّ الأمانة إلى من ائتمنك', hadithSource: 'أبو داود' },
    { id: 'respect', name: 'الاحترام', icon: '🤝', description: 'تقدير الآخرين ومعاملتهم بلطف', category: 'social', verse: 'يَا أَيُّهَا النَّاسُ إِنَّا خَلَقْنَاكُم مِّن ذَكَرٍ وَأُنثَىٰ', verseSource: 'الحجرات: 13', hadith: 'ليس منا من لم يوقر كبيرنا ويرحم صغيرنا', hadithSource: 'الترمذي' },
    { id: 'cooperation', name: 'التعاون', icon: '🤲', description: 'العمل معاً لتحقيق الخير', category: 'social', verse: 'وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ', verseSource: 'المائدة: 2', hadith: 'المؤمن للمؤمن كالبنيان يشد بعضه بعضاً', hadithSource: 'متفق عليه' },
    { id: 'patience', name: 'الصبر', icon: '🌿', description: 'التحمل والثبات عند الشدائد', category: 'personal', verse: 'إِنَّمَا يُوَفَّى الصَّابِرُونَ أَجْرَهُم بِغَيْرِ حِسَابٍ', verseSource: 'الزمر: 10', hadith: 'ما أُعطي أحد عطاءً خيراً وأوسع من الصبر', hadithSource: 'متفق عليه' },
    { id: 'gratitude', name: 'الشكر', icon: '🙏', description: 'الاعتراف بالنعم وحمد الله عليها', category: 'faith', verse: 'لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ', verseSource: 'إبراهيم: 7', hadith: 'من لا يشكر الناس لا يشكر الله', hadithSource: 'الترمذي' },
    { id: 'justice', name: 'العدل', icon: '⚖️', description: 'إعطاء كل ذي حق حقه', category: 'social', verse: 'إِنَّ اللَّهَ يَأْمُرُ بِالْعَدْلِ وَالْإِحْسَانِ', verseSource: 'النحل: 90', hadith: 'اتقوا الظلم فإن الظلم ظلمات يوم القيامة', hadithSource: 'مسلم' },
    { id: 'humility', name: 'التواضع', icon: '🌸', description: 'خفض الجناح وعدم التكبر', category: 'personal', verse: 'وَاخْفِضْ جَنَاحَكَ لِمَنِ اتَّبَعَكَ مِنَ الْمُؤْمِنِينَ', verseSource: 'الشعراء: 215', hadith: 'ما تواضع أحد لله إلا رفعه الله', hadithSource: 'مسلم' }
];

document.addEventListener('DOMContentLoaded', () => {
    renderValues();
    animateStats();
    setupEventListeners();
    updateLoginButton();
});

function renderValues(filter = 'all') {
    const grid = document.getElementById('valuesGrid');
    const filteredValues = filter === 'all' ? valuesData : valuesData.filter(v => v.category === filter);
    grid.innerHTML = filteredValues.map(value => {
        const progress = getValueProgress(value.id);
        return `<div class="value-card" onclick="showValue('${value.id}')" data-category="${value.category}">
            <div class="value-icon">${value.icon}</div>
            <h3>${value.name}</h3>
            <p>${value.description}</p>
            <div class="value-progress"><div class="value-progress-bar" style="width: ${progress}%"></div></div>
            <span class="value-progress-text">${progress}%</span>
        </div>`;
    }).join('');
}

function getValueProgress(valueId) {
    const user = JSON.parse(localStorage.getItem('noorUser') || '{}');
    return (user.progress && user.progress[valueId]) || 0;
}

function showValue(valueId) {
    const value = valuesData.find(v => v.id === valueId);
    if (!value) return;
    const modal = document.getElementById('valueModal');
    modal.innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;">
            <div style="font-size: 5rem; margin-bottom: 1rem;">${value.icon}</div>
            <h2 style="font-size: 2rem; margin-bottom: 0.5rem;">${value.name}</h2>
            <p style="color: var(--text-secondary);">${value.description}</p>
        </div>
        <div style="background: rgba(139, 92, 246, 0.1); padding: 1.5rem; border-radius: 12px; border-right: 4px solid var(--primary); margin-bottom: 1.5rem;">
            <h4 style="margin-bottom: 0.5rem;">📖 الشاهد القرآني</h4>
            <p style="font-style: italic; margin-bottom: 0.5rem;">"${value.verse}"</p>
            <small style="color: var(--text-secondary);">— ${value.verseSource}</small>
        </div>
        <div style="background: rgba(6, 182, 212, 0.1); padding: 1.5rem; border-radius: 12px; border-right: 4px solid var(--secondary); margin-bottom: 2rem;">
            <h4 style="margin-bottom: 0.5rem;">📿 الحديث النبوي</h4>
            <p style="font-style: italic; margin-bottom: 0.5rem;">"${value.hadith}"</p>
            <small style="color: var(--text-secondary);">— ${value.hadithSource}</small>
        </div>
        <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <button class="btn-primary" onclick="startQuiz('${value.id}')" style="flex: 1;"><span>📝</span><span>ابدأ الاختبار</span></button>
            <button class="btn-secondary" onclick="closeModal()" style="flex: 1;"><span>إغلاق</span></button>
        </div>
    </div>`;
    modal.classList.add('active');
}

function closeModal() { document.getElementById('valueModal').classList.remove('active'); }

function animateStats() {
    document.querySelectorAll('.stat-number').forEach(stat => {
        const target = parseInt(stat.dataset.target);
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) { stat.textContent = target; clearInterval(timer); }
            else { stat.textContent = Math.floor(current); }
        }, 30);
    });
}

function setupEventListeners() {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderValues(btn.dataset.filter);
        });
    });
    document.querySelector('.login-btn').addEventListener('click', () => {
        const user = JSON.parse(localStorage.getItem('noorUser') || 'null');
        user ? showProfilePage() : showLoginModal();
    });
    document.getElementById('valueModal').addEventListener('click', (e) => { if (e.target.id === 'valueModal') closeModal(); });
    document.getElementById('authModal').addEventListener('click', (e) => { if (e.target.id === 'authModal') closeAuthModal(); });
}

function updateLoginButton() {
    const user = JSON.parse(localStorage.getItem('noorUser') || 'null');
    const btn = document.querySelector('.login-btn');
    btn.innerHTML = user ? `<span style="background: var(--accent); width: 30px; height: 30px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-left: 0.5rem;">${user.name.charAt(0)}</span> ${user.name}` : 'تسجيل الدخول';
}

function startActivity(type) {
    const user = JSON.parse(localStorage.getItem('noorUser') || 'null');
    if (!user) { showLoginModal(); return; }
    if (type === 'quiz') showQuizSelection();
    else if (type === 'stories') showStoriesPage();
    else if (type === 'challenges') showChallengesPage();
    else if (type === 'games') showGamesPage();
}

function startQuiz(valueId) {
    const user = JSON.parse(localStorage.getItem('noorUser') || 'null');
    if (!user) { closeModal(); showLoginModal(); return; }
    const value = valuesData.find(v => v.id === valueId);
    if (!value) return;
    const questions = getQuizQuestions(valueId);
    let currentQuestion = 0, score = 0;
    
    function showQuestion() {
        const q = questions[currentQuestion];
        document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
            <button class="modal-close" onclick="closeModal()">×</button>
            <div style="text-align: center; margin-bottom: 2rem;">
                <span style="font-size: 3rem;">${value.icon}</span>
                <h3 style="margin-top: 1rem;">اختبار ${value.name}</h3>
                <div style="background: var(--bg-dark); height: 8px; border-radius: 4px; margin-top: 1rem; overflow: hidden;">
                    <div style="background: var(--gradient-1); height: 100%; width: ${((currentQuestion + 1) / questions.length) * 100}%;"></div>
                </div>
                <small style="color: var(--text-secondary);">السؤال ${currentQuestion + 1} من ${questions.length}</small>
            </div>
            <div style="background: var(--bg-dark); padding: 1.5rem; border-radius: 12px; margin-bottom: 1.5rem;">
                <h4>${q.question}</h4>
            </div>
            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                ${q.options.map((opt, i) => `<button onclick="selectAnswer(${i}, ${q.correct})" style="background: var(--bg-dark); border: 1px solid var(--border); color: var(--text-primary); padding: 1rem; border-radius: 12px; text-align: right; cursor: pointer; font-family: inherit; font-size: 1rem;">${opt}</button>`).join('')}
            </div>
        </div>`;
    }
    
    window.selectAnswer = function(selected, correct) {
        if (selected === correct) score++;
        currentQuestion++;
        currentQuestion < questions.length ? showQuestion() : showQuizResult(valueId, score, questions.length);
    };
    showQuestion();
}

function showQuizResult(valueId, score, total) {
    const value = valuesData.find(v => v.id === valueId);
    const percentage = Math.round((score / total) * 100);
    const user = JSON.parse(localStorage.getItem('noorUser') || '{}');
    if (!user.progress) user.progress = {};
    user.progress[valueId] = Math.max(user.progress[valueId] || 0, percentage);
    user.points = (user.points || 0) + score * 10;
    user.quizzes = (user.quizzes || 0) + 1;
    localStorage.setItem('noorUser', JSON.stringify(user));
    
    document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem; text-align: center;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="font-size: 5rem; margin-bottom: 1rem;">${percentage >= 80 ? '🏆' : percentage >= 60 ? '⭐' : '💪'}</div>
        <h2>${percentage >= 80 ? 'ممتاز!' : percentage >= 60 ? 'جيد جداً!' : 'حاول مرة أخرى!'}</h2>
        <p style="color: var(--text-secondary); margin-bottom: 2rem;">حصلت على ${score} من ${total} في اختبار ${value.name}</p>
        <div style="background: var(--bg-dark); padding: 2rem; border-radius: 16px; margin-bottom: 2rem;">
            <div style="font-size: 4rem; font-weight: 800; background: var(--gradient-1); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">${percentage}%</div>
            <p style="color: var(--text-secondary);">+ ${score * 10} نقطة</p>
        </div>
        <div style="display: flex; gap: 1rem;">
            <button class="btn-primary" onclick="startQuiz('${valueId}')" style="flex: 1;">إعادة الاختبار</button>
            <button class="btn-secondary" onclick="closeModal(); renderValues();" style="flex: 1;">إغلاق</button>
        </div>
    </div>`;
    if (percentage >= 80) createConfetti();
    updateLoginButton();
}

function getQuizQuestions(valueId) {
    const q = {
        honesty: [{ question: 'ما معنى الصدق؟', options: ['قول الحق', 'الكذب', 'السرقة', 'الغش'], correct: 0 }, { question: 'ما جزاء الصادقين؟', options: ['العقاب', 'البر والجنة', 'الفقر', 'الوحدة'], correct: 1 }, { question: 'من صفات المؤمن؟', options: ['الكذب', 'الصدق', 'الخيانة', 'الغدر'], correct: 1 }, { question: 'الصدق يهدي إلى؟', options: ['النار', 'البر', 'الكذب', 'الفجور'], correct: 1 }, { question: 'ضد الصدق هو؟', options: ['الأمانة', 'الكذب', 'الصبر', 'الشكر'], correct: 1 }],
        trust: [{ question: 'ما معنى الأمانة؟', options: ['حفظ الحقوق', 'السرقة', 'الكذب', 'الخيانة'], correct: 0 }, { question: 'من صفات المنافق؟', options: ['الصدق', 'خيانة الأمانة', 'الوفاء', 'الأمانة'], correct: 1 }, { question: 'الأمانة تشمل؟', options: ['المال فقط', 'الأسرار فقط', 'كل شيء', 'لا شيء'], correct: 2 }, { question: 'أداء الأمانة واجب على؟', options: ['الكبار فقط', 'الجميع', 'الأغنياء', 'العلماء'], correct: 1 }, { question: 'خيانة الأمانة من صفات؟', options: ['المؤمنين', 'المنافقين', 'الصالحين', 'الأنبياء'], correct: 1 }],
        respect: [{ question: 'الاحترام يعني؟', options: ['تقدير الآخرين', 'إهانتهم', 'تجاهلهم', 'السخرية منهم'], correct: 0 }, { question: 'من نحترم؟', options: ['الأغنياء فقط', 'الجميع', 'الكبار فقط', 'الأصدقاء فقط'], correct: 1 }, { question: 'احترام الكبير من؟', options: ['الأخلاق السيئة', 'الأخلاق الحسنة', 'الضعف', 'الخوف'], correct: 1 }, { question: 'عكس الاحترام؟', options: ['التقدير', 'الإهانة', 'الحب', 'الصداقة'], correct: 1 }, { question: 'الاحترام يبدأ من؟', options: ['المدرسة', 'البيت', 'الشارع', 'العمل'], correct: 1 }],
        cooperation: [{ question: 'التعاون يعني؟', options: ['العمل وحيداً', 'العمل معاً', 'الكسل', 'الأنانية'], correct: 1 }, { question: 'نتعاون على؟', options: ['الشر', 'البر والتقوى', 'الإثم', 'العدوان'], correct: 1 }, { question: 'التعاون يقوي؟', options: ['الفرقة', 'الوحدة', 'الضعف', 'الكراهية'], correct: 1 }, { question: 'المؤمن للمؤمن كـ؟', options: ['الأعداء', 'البنيان', 'الغرباء', 'المتنافسين'], correct: 1 }, { question: 'التعاون من القيم؟', options: ['السيئة', 'الإسلامية', 'المرفوضة', 'القديمة'], correct: 1 }],
        patience: [{ question: 'الصبر يعني؟', options: ['الاستسلام', 'التحمل والثبات', 'الضعف', 'الخوف'], correct: 1 }, { question: 'جزاء الصابرين؟', options: ['محدود', 'بغير حساب', 'قليل', 'معدوم'], correct: 1 }, { question: 'الصبر عند؟', options: ['الفرح فقط', 'المصائب', 'النوم', 'الأكل'], correct: 1 }, { question: 'الصبر من صفات؟', options: ['الضعفاء', 'الأقوياء', 'الجبناء', 'الكسالى'], correct: 1 }, { question: 'أنواع الصبر؟', options: ['نوع واحد', 'ثلاثة أنواع', 'لا يوجد', 'عشرة'], correct: 1 }],
        gratitude: [{ question: 'الشكر يعني؟', options: ['الجحود', 'الاعتراف بالنعم', 'النسيان', 'الإنكار'], correct: 1 }, { question: 'من نشكر؟', options: ['الله فقط', 'الناس فقط', 'الله والناس', 'لا أحد'], correct: 2 }, { question: 'جزاء الشاكرين؟', options: ['النقص', 'الزيادة', 'الثبات', 'العقاب'], correct: 1 }, { question: 'الشكر يكون بـ؟', options: ['القلب فقط', 'اللسان فقط', 'القلب واللسان والعمل', 'لا شيء'], correct: 2 }, { question: 'عكس الشكر؟', options: ['الحمد', 'الكفر بالنعمة', 'الرضا', 'القناعة'], correct: 1 }],
        justice: [{ question: 'العدل يعني؟', options: ['الظلم', 'إعطاء كل ذي حق حقه', 'التفريق', 'المحاباة'], correct: 1 }, { question: 'الله يأمر بـ؟', options: ['الظلم', 'العدل', 'التفريق', 'الكراهية'], correct: 1 }, { question: 'العدل واجب مع؟', options: ['الأصدقاء فقط', 'الجميع', 'الأقارب فقط', 'المسلمين فقط'], correct: 1 }, { question: 'الظلم يوم القيامة؟', options: ['نور', 'ظلمات', 'راحة', 'سعادة'], correct: 1 }, { question: 'القاضي العادل يوم القيامة؟', options: ['يُعاقب', 'على منابر من نور', 'يُنسى', 'يُهمل'], correct: 1 }],
        humility: [{ question: 'التواضع يعني؟', options: ['التكبر', 'خفض الجناح', 'الغرور', 'العجب'], correct: 1 }, { question: 'من تواضع لله؟', options: ['أذله', 'رفعه', 'تركه', 'عاقبه'], correct: 1 }, { question: 'عكس التواضع؟', options: ['اللين', 'الكبر', 'الرحمة', 'العطف'], correct: 1 }, { question: 'التواضع من صفات؟', options: ['المتكبرين', 'الأنبياء والصالحين', 'الظالمين', 'الجاهلين'], correct: 1 }, { question: 'المتواضع يحبه؟', options: ['لا أحد', 'الله والناس', 'الشياطين', 'المتكبرون'], correct: 1 }]
    };
    return q[valueId] || q.honesty;
}

function createConfetti() {
    for (let i = 0; i < 50; i++) {
        const c = document.createElement('div');
        c.style.cssText = `position:fixed;width:10px;height:10px;background:${['#8b5cf6','#06b6d4','#f59e0b','#10b981','#ef4444'][Math.floor(Math.random()*5)]};top:-10px;left:${Math.random()*100}vw;opacity:${Math.random()};transform:rotate(${Math.random()*360}deg);animation:fall ${2+Math.random()*3}s linear forwards;z-index:9999;border-radius:${Math.random()>0.5?'50%':'0'}`;
        document.body.appendChild(c);
        setTimeout(() => c.remove(), 5000);
    }
    if (!document.getElementById('confettiStyle')) {
        const s = document.createElement('style');
        s.id = 'confettiStyle';
        s.textContent = '@keyframes fall{to{transform:translateY(100vh) rotate(720deg);opacity:0}}';
        document.head.appendChild(s);
    }
}
