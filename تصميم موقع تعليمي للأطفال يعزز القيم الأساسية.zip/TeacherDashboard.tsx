import { useState } from "react";
import { studentsData, valuesData } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, FileDown, Search, Filter, MoreHorizontal, ArrowRight } from "lucide-react";
import { toast } from "sonner";

export default function TeacherDashboard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClass, setSelectedClass] = useState("all");

  const filteredStudents = studentsData.filter(student => 
    student.name.includes(searchTerm) && 
    (selectedClass === "all" || student.grade === selectedClass)
  );

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("تم إضافة النشاط الجديد بنجاح");
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold text-gray-800">لوحة المعلم</h1>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="gap-2">
              <FileDown className="w-4 h-4" />
              تصدير التقرير
            </Button>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="gap-2 bg-primary hover:bg-primary/90">
                  <Plus className="w-4 h-4" />
                  نشاط جديد
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>إضافة نشاط جديد</DialogTitle>
                  <DialogDescription>
                    أدخل تفاصيل النشاط الجديد لتعيينه للطلاب.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddActivity} className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">عنوان النشاط</Label>
                    <Input id="title" placeholder="مثال: مساعدة الزملاء" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="value">القيمة المرتبطة</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر القيمة" />
                      </SelectTrigger>
                      <SelectContent>
                        {valuesData.map(v => (
                          <SelectItem key={v.id} value={v.id}>{v.title}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">نوع النشاط</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر النوع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="class">صفّي</SelectItem>
                        <SelectItem value="home">منزلي</SelectItem>
                        <SelectItem value="digital">رقمي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="w-full">حفظ النشاط</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-sm font-medium text-gray-500 mb-2">إجمالي الطلاب</h3>
            <p className="text-3xl font-bold text-gray-900">{studentsData.length}</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-sm font-medium text-gray-500 mb-2">متوسط التقدم</h3>
            <p className="text-3xl font-bold text-blue-600">72%</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-sm font-medium text-gray-500 mb-2">الأنشطة المكتملة</h3>
            <p className="text-3xl font-bold text-green-600">145</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-grow max-w-md">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input 
              placeholder="بحث عن طالب..." 
              className="pr-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select value={selectedClass} onValueChange={setSelectedClass}>
            <SelectTrigger className="w-[180px]">
              <Filter className="w-4 h-4 ml-2" />
              <SelectValue placeholder="تصفية حسب الصف" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الصفوف</SelectItem>
              <SelectItem value="الرابع - أ">الرابع - أ</SelectItem>
              <SelectItem value="الرابع - ب">الرابع - ب</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Students Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/50">
                <TableHead className="text-right font-bold">اسم الطالب</TableHead>
                <TableHead className="text-right font-bold">الصف</TableHead>
                <TableHead className="text-right font-bold">مستوى التقدم</TableHead>
                {valuesData.slice(0, 4).map(value => (
                  <TableHead key={value.id} className="text-center font-bold text-xs text-gray-500">
                    {value.title}
                  </TableHead>
                ))}
                <TableHead className="text-left font-bold">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.map((student) => (
                <TableRow key={student.id} className="hover:bg-gray-50/50 transition-colors">
                  <TableCell className="font-medium">{student.name}</TableCell>
                  <TableCell className="text-gray-500">{student.grade}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-500 rounded-full" 
                          style={{ width: `${student.progress}%` }}
                        />
                      </div>
                      <span className="text-xs font-bold text-gray-600">{student.progress}%</span>
                    </div>
                  </TableCell>
                  {/* Mock data for individual values */}
                  <TableCell className="text-center"><span className="inline-block w-2 h-2 rounded-full bg-green-500" /></TableCell>
                  <TableCell className="text-center"><span className="inline-block w-2 h-2 rounded-full bg-yellow-500" /></TableCell>
                  <TableCell className="text-center"><span className="inline-block w-2 h-2 rounded-full bg-blue-500" /></TableCell>
                  <TableCell className="text-center"><span className="inline-block w-2 h-2 rounded-full bg-green-500" /></TableCell>
                  <TableCell className="text-left">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
}
