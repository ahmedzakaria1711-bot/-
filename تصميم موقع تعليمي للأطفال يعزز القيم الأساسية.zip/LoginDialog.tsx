import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LogIn, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useStudent } from "@/contexts/StudentContext";

export function LoginDialog() {
  const { login, register, isLoading } = useStudent();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [open, setOpen] = useState(false);
  
  // Login fields
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  
  // Register fields
  const [name, setName] = useState("");
  const [stage, setStage] = useState<"elementary" | "">("");
  const [grade, setGrade] = useState("");
  const [gender, setGender] = useState<"boy" | "girl">("boy");

  const gradeOptions = stage === "elementary" 
    ? [
        { id: "1", name: "الأول الابتدائي" },
        { id: "2", name: "الثاني الابتدائي" },
        { id: "3", name: "الثالث الابتدائي" },
        { id: "4", name: "الرابع الابتدائي" },
        { id: "5", name: "الخامس الابتدائي" },
        { id: "6", name: "السادس الابتدائي" },
      ]
    : [];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    const result = await login(email, password);
    if (result.success) {
      setOpen(false);
      toast.success("مرحباً بعودتك!");
      resetForm();
    } else {
      toast.error(result.error || "فشل تسجيل الدخول");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password || !grade || !stage) return;

    if (password.length < 6) {
      toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }

    const result = await register({ name, email, password, grade, gender });
    if (result.success) {
      setOpen(false);
      toast.success(`مرحباً بك يا ${gender === "boy" ? "بطل" : "بطلة"} ${name}!`);
      resetForm();
    } else {
      toast.error(result.error || "فشل إنشاء الحساب");
    }
  };

  const resetForm = () => {
    setEmail("");
    setPassword("");
    setName("");
    setStage("");
    setGrade("");
    setGender("boy");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <LogIn className="w-4 h-4" />
          تسجيل الدخول
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === "login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}</DialogTitle>
          <DialogDescription>
            {mode === "login" 
              ? "أدخل بريدك الإلكتروني وكلمة المرور للدخول"
              : "أنشئ حسابك لتبدأ رحلة القيم الممتعة!"
            }
          </DialogDescription>
        </DialogHeader>

        {mode === "login" ? (
          <form onSubmit={handleLogin} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input 
                id="email" 
                type="email"
                placeholder="example@email.com" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input 
                id="password" 
                type="password"
                placeholder="••••••••" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                dir="ltr"
              />
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
              تسجيل الدخول
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              ليس لديك حساب؟{" "}
              <button type="button" onClick={() => setMode("register")} className="text-primary hover:underline">
                إنشاء حساب جديد
              </button>
            </p>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">اسم الطالب / الطالبة</Label>
              <Input 
                id="name" 
                placeholder="اكتب اسمك هنا..." 
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reg-email">البريد الإلكتروني</Label>
              <Input 
                id="reg-email" 
                type="email"
                placeholder="example@email.com" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                dir="ltr"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reg-password">كلمة المرور</Label>
              <Input 
                id="reg-password" 
                type="password"
                placeholder="6 أحرف على الأقل" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                dir="ltr"
              />
            </div>

            <div className="space-y-3">
              <Label>المرحلة الدراسية</Label>
              <div 
                onClick={() => { setStage("elementary"); setGrade(""); }}
                className={`cursor-pointer rounded-xl border-2 p-4 flex flex-col items-center gap-2 transition-all ${stage === "elementary" ? "border-sky-500 bg-sky-50" : "border-transparent bg-gray-50 hover:bg-gray-100"}`}
              >
                <span className="text-3xl">🌟</span>
                <span className="font-bold text-sky-700">المرحلة الابتدائية</span>
                <span className="text-xs text-gray-500">الصف 1 - 6</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="grade">الصف الدراسي</Label>
              <Select value={grade} onValueChange={setGrade} disabled={!stage} required>
                <SelectTrigger>
                  <SelectValue placeholder={stage ? "اختر الصف..." : "اختر المرحلة أولاً"} />
                </SelectTrigger>
                <SelectContent>
                  {gradeOptions.map((g) => (
                    <SelectItem key={g.id} value={g.name}>{g.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>أنا...</Label>
              <RadioGroup value={gender} onValueChange={(v) => setGender(v as "boy" | "girl")} className="flex gap-3">
                <div className={`flex-1 cursor-pointer rounded-xl border-2 p-3 flex flex-col items-center gap-1 transition-all ${gender === "boy" ? "border-blue-500 bg-blue-50" : "border-transparent bg-gray-50 hover:bg-gray-100"}`}>
                  <RadioGroupItem value="boy" id="boy" className="sr-only" />
                  <Label htmlFor="boy" className="cursor-pointer flex flex-col items-center gap-1 w-full">
                    <img src="/images/guide-boy.png" alt="Boy" className="w-12 h-12 object-contain" />
                    <span className="font-bold text-blue-700 text-sm">بطل</span>
                  </Label>
                </div>
                <div className={`flex-1 cursor-pointer rounded-xl border-2 p-3 flex flex-col items-center gap-1 transition-all ${gender === "girl" ? "border-pink-500 bg-pink-50" : "border-transparent bg-gray-50 hover:bg-gray-100"}`}>
                  <RadioGroupItem value="girl" id="girl" className="sr-only" />
                  <Label htmlFor="girl" className="cursor-pointer flex flex-col items-center gap-1 w-full">
                    <img src="/images/guide-girl.png" alt="Girl" className="w-12 h-12 object-contain" />
                    <span className="font-bold text-pink-700 text-sm">بطلة</span>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
              إنشاء الحساب 🚀
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              لديك حساب بالفعل؟{" "}
              <button type="button" onClick={() => setMode("login")} className="text-primary hover:underline">
                تسجيل الدخول
              </button>
            </p>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
