import { Link, useLocation } from "wouter";
import { Home, Trophy, ShoppingBag, Swords, BookOpen, User, Settings, Users, MessageSquare, Send } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const menuItems = [
  { icon: Home, label: "الرئيسية", href: "/" },
  { icon: Trophy, label: "إنجازاتي", href: "/achievements" },

  { icon: BookOpen, label: "المكتبة", href: "/library" }, // New Library page

];

export function Sidebar() {
  const [location] = useLocation();
  const [feedbackOpen, setFeedbackOpen] = useState(false);

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedbackOpen(false);
    toast.success("شكراً لك! تم إرسال ملاحظاتك بنجاح.");
  };

  return (
    <aside className="fixed right-0 top-1/2 -translate-y-1/2 z-40 hidden lg:flex flex-col gap-2 p-2 bg-white/90 backdrop-blur-md border border-gray-200 rounded-l-2xl shadow-lg transition-all duration-300 hover:pl-4">
      {menuItems.map((item) => {
        const Icon = item.icon;
        const isActive = location === item.href;
        
        return (
          <Tooltip key={item.href} delayDuration={0}>
            <TooltipTrigger asChild>
              <Link href={item.href}>
                <div 
                  className={cn(
                    "w-12 h-12 flex items-center justify-center rounded-xl transition-all duration-200 cursor-pointer group relative",
                    isActive 
                      ? "bg-primary text-primary-foreground shadow-md scale-110" 
                      : "text-muted-foreground hover:bg-secondary hover:text-secondary-foreground hover:scale-105"
                  )}
                >
                  <Icon className="w-6 h-6" />
                  {isActive && (
                    <span className="absolute right-full mr-2 bg-primary text-primary-foreground text-xs font-bold px-2 py-1 rounded-md whitespace-nowrap shadow-sm animate-in fade-in slide-in-from-right-2">
                      {item.label}
                    </span>
                  )}
                </div>
              </Link>
            </TooltipTrigger>
            <TooltipContent side="left" className="font-bold">
              {item.label}
            </TooltipContent>
          </Tooltip>
        );
      })}
      
      <Dialog open={feedbackOpen} onOpenChange={setFeedbackOpen}>
        <DialogTrigger asChild>
          <div className="w-12 h-12 flex items-center justify-center rounded-xl transition-all duration-200 cursor-pointer text-muted-foreground hover:bg-secondary hover:text-secondary-foreground hover:scale-105 mt-2 border-t border-gray-100">
            <MessageSquare className="w-6 h-6" />
          </div>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>رأيك يهمنا</DialogTitle>
            <DialogDescription>
              ساعدنا في تحسين "قِيَمي" بإرسال ملاحظاتك أو الإبلاغ عن مشكلة.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleFeedbackSubmit} className="space-y-4">
            <Textarea placeholder="اكتب ملاحظاتك هنا..." className="min-h-[100px]" required />
            <Button type="submit" className="w-full">
              <Send className="w-4 h-4 ml-2" />
              إرسال الملاحظات
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </aside>
  );
}
