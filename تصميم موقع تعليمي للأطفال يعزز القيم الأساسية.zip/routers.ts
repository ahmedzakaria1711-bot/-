import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { students, studentProgress, notifications, values, activities, storeItems, feedback, challenges } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Student routes
  student: router({
    // Register or update student profile
    register: publicProcedure
      .input(z.object({
        name: z.string().min(2),
        email: z.string().email(),
        password: z.string().min(6),
        grade: z.string(),
        gender: z.enum(["boy", "girl"]),
        userId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Check if email already exists
        const existing = await db.select().from(students).where(eq(students.email, input.email)).limit(1);
        if (existing.length > 0) {
          throw new Error("Email already registered");
        }

        const result = await db.insert(students).values({
          name: input.name,
          email: input.email,
          password: input.password,
          grade: input.grade,
          gender: input.gender,
          userId: input.userId || null,
          points: 100,
          totalProgress: 0,
          achievements: [],
        });

        return { success: true, studentId: Number(result[0].insertId) };
      }),

    // Login with email and password
    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const student = await db.select().from(students).where(eq(students.email, input.email)).limit(1);
        if (student.length === 0) {
          throw new Error("Invalid email or password");
        }

        if (student[0].password !== input.password) {
          throw new Error("Invalid email or password");
        }

        return { success: true, student: student[0] };
      }),

    // Add achievement to student
    addAchievement: publicProcedure
      .input(z.object({
        studentId: z.number(),
        achievementId: z.string(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const student = await db.select().from(students).where(eq(students.id, input.studentId)).limit(1);
        if (student.length === 0) throw new Error("Student not found");

        const currentAchievements = student[0].achievements || [];
        if (!currentAchievements.includes(input.achievementId)) {
          currentAchievements.push(input.achievementId);
          await db.update(students)
            .set({ achievements: currentAchievements })
            .where(eq(students.id, input.studentId));
        }

        return { success: true, achievements: currentAchievements };
      }),

    // Get student achievements
    getAchievements: publicProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];

        const student = await db.select().from(students).where(eq(students.id, input.studentId)).limit(1);
        return student[0]?.achievements || [];
      }),

    // Get student by ID
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;

        const result = await db.select().from(students).where(eq(students.id, input.id)).limit(1);
        return result[0] || null;
      }),

    // Update student points
    updatePoints: publicProcedure
      .input(z.object({
        studentId: z.number(),
        points: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.update(students)
          .set({ points: input.points })
          .where(eq(students.id, input.studentId));

        return { success: true };
      }),

    // Get all students (for teacher dashboard)
    getAll: protectedProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];

      return await db.select().from(students);
    }),
  }),

  // Progress routes
  progress: router({
    // Get student progress for all values
    getByStudent: publicProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];

        return await db.select()
          .from(studentProgress)
          .where(eq(studentProgress.studentId, input.studentId));
      }),

    // Update progress for a specific value
    update: publicProcedure
      .input(z.object({
        studentId: z.number(),
        valueId: z.string(),
        progress: z.number(),
        level: z.enum(["beginner", "developing", "stable", "excellent"]).optional(),
        completedActivities: z.array(z.number()).optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Check if progress record exists
        const existing = await db.select()
          .from(studentProgress)
          .where(and(
            eq(studentProgress.studentId, input.studentId),
            eq(studentProgress.valueId, input.valueId)
          ))
          .limit(1);

        if (existing.length > 0) {
          // Update existing
          await db.update(studentProgress)
            .set({
              progress: input.progress,
              level: input.level || existing[0].level,
              completedActivities: input.completedActivities || existing[0].completedActivities,
            })
            .where(eq(studentProgress.id, existing[0].id));
        } else {
          // Insert new
          await db.insert(studentProgress).values({
            studentId: input.studentId,
            valueId: input.valueId,
            progress: input.progress,
            level: input.level || "beginner",
            completedActivities: input.completedActivities || [],
          });
        }

        return { success: true };
      }),

    // Complete an activity
    completeActivity: publicProcedure
      .input(z.object({
        studentId: z.number(),
        valueId: z.string(),
        activityId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Get current progress
        const existing = await db.select()
          .from(studentProgress)
          .where(and(
            eq(studentProgress.studentId, input.studentId),
            eq(studentProgress.valueId, input.valueId)
          ))
          .limit(1);

        const currentActivities = existing[0]?.completedActivities || [];
        if (!currentActivities.includes(input.activityId)) {
          currentActivities.push(input.activityId);
        }

        const newProgress = Math.min(100, (currentActivities.length / 3) * 100);
        const newLevel = newProgress >= 100 ? "excellent" : 
                        newProgress >= 66 ? "stable" : 
                        newProgress >= 33 ? "developing" : "beginner";

        if (existing.length > 0) {
          await db.update(studentProgress)
            .set({
              progress: newProgress,
              level: newLevel,
              completedActivities: currentActivities,
            })
            .where(eq(studentProgress.id, existing[0].id));
        } else {
          await db.insert(studentProgress).values({
            studentId: input.studentId,
            valueId: input.valueId,
            progress: newProgress,
            level: newLevel,
            completedActivities: currentActivities,
          });
        }

        // Add points to student
        const studentData = await db.select().from(students).where(eq(students.id, input.studentId)).limit(1);
        if (studentData[0]) {
          await db.update(students)
            .set({ points: studentData[0].points + 10 })
            .where(eq(students.id, input.studentId));
        }

        return { success: true, newProgress, newLevel };
      }),
  }),

  // Notifications routes
  notifications: router({
    // Get notifications for a student
    getByStudent: publicProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];

        return await db.select()
          .from(notifications)
          .where(eq(notifications.studentId, input.studentId))
          .orderBy(desc(notifications.createdAt));
      }),

    // Send notification (for teachers)
    send: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        type: z.enum(["star", "badge", "message", "achievement"]),
        title: z.string(),
        content: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.insert(notifications).values({
          studentId: input.studentId,
          fromTeacherId: ctx.user?.id || null,
          type: input.type,
          title: input.title,
          content: input.content || null,
        });

        return { success: true };
      }),

    // Mark notification as read
    markRead: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.update(notifications)
          .set({ isRead: true })
          .where(eq(notifications.id, input.id));

        return { success: true };
      }),
  }),

  // Store routes
  store: router({
    // Get all store items
    getItems: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];

      return await db.select()
        .from(storeItems)
        .where(eq(storeItems.isActive, true));
    }),

    // Purchase item
    purchase: publicProcedure
      .input(z.object({
        studentId: z.number(),
        itemId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Get item price
        const item = await db.select()
          .from(storeItems)
          .where(eq(storeItems.id, input.itemId))
          .limit(1);

        if (!item[0]) throw new Error("Item not found");

        // Get student points
        const student = await db.select()
          .from(students)
          .where(eq(students.id, input.studentId))
          .limit(1);

        if (!student[0]) throw new Error("Student not found");
        if (student[0].points < item[0].price) throw new Error("Not enough points");

        // Deduct points and add to inventory
        const currentInventory = student[0].inventory || [];
        currentInventory.push(item[0].id.toString());

        await db.update(students)
          .set({
            points: student[0].points - item[0].price,
            inventory: currentInventory,
          })
          .where(eq(students.id, input.studentId));

        return { success: true, newPoints: student[0].points - item[0].price };
      }),
  }),

  // Feedback routes
  feedback: router({
    submit: publicProcedure
      .input(z.object({
        studentId: z.number().optional(),
        type: z.enum(["suggestion", "bug", "praise", "other"]),
        content: z.string(),
        rating: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.insert(feedback).values({
          userId: ctx.user?.id || null,
          studentId: input.studentId || null,
          type: input.type,
          content: input.content,
          rating: input.rating || null,
        });

        return { success: true };
      }),

    // Get all feedback (for admin)
    getAll: protectedProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];

      return await db.select()
        .from(feedback)
        .orderBy(desc(feedback.createdAt));
    }),
  }),

  // Challenges routes
  challenges: router({
    getActive: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];

      return await db.select()
        .from(challenges)
        .where(eq(challenges.isActive, true));
    }),

    contribute: publicProcedure
      .input(z.object({
        challengeId: z.number(),
        points: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const challengeData = await db.select().from(challenges).where(eq(challenges.id, input.challengeId)).limit(1);
        if (challengeData[0]) {
          await db.update(challenges)
            .set({ currentPoints: challengeData[0].currentPoints + input.points })
            .where(eq(challenges.id, input.challengeId));
        }

        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
