import { Value } from "@/lib/data";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface ValueCardProps {
  value: Value;
}

export function ValueCard({ value }: ValueCardProps) {
  const Icon = value.icon;

  return (
    <Link href={`/activity/${value.id}`}>
      <div className="clay-card p-6 flex flex-col h-full relative overflow-hidden group cursor-pointer hover:ring-2 hover:ring-primary/30 transition-all">
        {/* Decorative Background Shape */}
        <div className={cn("absolute -right-8 -top-8 w-32 h-32 rounded-full opacity-10 transition-transform group-hover:scale-110", value.color.split(" ")[1])} />
        
        <div className="flex items-start justify-between mb-4 relative z-10">
          <div className={cn("p-3 rounded-2xl shadow-sm", value.color)}>
            <Icon className="w-8 h-8" />
          </div>
          <span className="text-sm font-bold text-muted-foreground bg-white/50 px-3 py-1 rounded-full backdrop-blur-sm">
            {value.level}
          </span>
        </div>

        <h3 className="text-2xl font-bold mb-2 text-foreground">{value.title}</h3>
        <p className="text-muted-foreground text-sm mb-6 flex-grow leading-relaxed">
          {value.description}
        </p>

        <div className="space-y-4 relative z-10">
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-medium text-muted-foreground">
              <span>مستوى التقدم</span>
              <span>{value.progress}%</span>
            </div>
            <Progress value={value.progress} className={cn("h-3 bg-gray-100 [&>div]:bg-current", value.color.split(" ")[0])} />
          </div>

          <div className={cn("w-full clay-button font-bold text-white hover:opacity-90 py-2 px-4 rounded-md flex items-center justify-center gap-2", value.color.split(" ")[0].replace("text-", "bg-"))}>
            ابدأ النشاط
            <ArrowLeft className="h-4 w-4" />
          </div>
        </div>
      </div>
    </Link>
  );
}
