// نظام المصادقة
function showLoginModal() {
    const modal = document.getElementById('authModal');
    document.getElementById('authModalBody').innerHTML = `
        <div class="auth-container">
            <div class="auth-header">
                <span class="auth-icon">🔐</span>
                <h2>تسجيل الدخول</h2>
                <p>أهلاً بك في نُور القيم</p>
            </div>
            <form class="auth-form" onsubmit="handleLogin(event)">
                <div class="form-group">
                    <label>البريد الإلكتروني</label>
                    <input type="email" id="loginEmail" required placeholder="example@email.com">
                </div>
                <div class="form-group">
                    <label>كلمة المرور</label>
                    <input type="password" id="loginPassword" required placeholder="••••••••">
                </div>
                <button type="submit" class="btn-primary auth-btn">تسجيل الدخول</button>
            </form>
            <div class="auth-footer">
                <p>ليس لديك حساب؟</p>
                <button class="link-btn" onclick="showRegisterModal()">إنشاء حساب جديد</button>
            </div>
        </div>
    `;
    modal.classList.add('active');
}

function showRegisterModal() {
    document.getElementById('authModalBody').innerHTML = `
        <div class="auth-container">
            <div class="auth-header">
                <span class="auth-icon">✨</span>
                <h2>إنشاء حساب جديد</h2>
                <p>انضم إلى رحلة القيم</p>
            </div>
            <form class="auth-form" onsubmit="handleRegister(event)">
                <div class="form-group">
                    <label>الاسم الكامل</label>
                    <input type="text" id="regName" required placeholder="أدخل اسمك">
                </div>
                <div class="form-group">
                    <label>البريد الإلكتروني</label>
                    <input type="email" id="regEmail" required placeholder="example@email.com">
                </div>
                <div class="form-group">
                    <label>كلمة المرور</label>
                    <input type="password" id="regPassword" required placeholder="••••••••">
                </div>
                <div class="form-group">
                    <label>الصف الدراسي</label>
                    <select id="regGrade" required>
                        <option value="">اختر الصف</option>
                        <option value="7">الصف الأول متوسط</option>
                        <option value="8">الصف الثاني متوسط</option>
                        <option value="9">الصف الثالث متوسط</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary auth-btn">إنشاء الحساب</button>
            </form>
            <div class="auth-footer">
                <p>لديك حساب بالفعل؟</p>
                <button class="link-btn" onclick="showLoginModal()">تسجيل الدخول</button>
            </div>
        </div>
    `;
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const users = JSON.parse(localStorage.getItem('noorUsers') || '[]');
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
        localStorage.setItem('noorUser', JSON.stringify(user));
        closeAuthModal();
        updateLoginButton();
        renderValues();
        alert('أهلاً بك ' + user.name + '! 🎉');
    } else {
        alert('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    }
}

function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const grade = document.getElementById('regGrade').value;
    const users = JSON.parse(localStorage.getItem('noorUsers') || '[]');
    if (users.find(u => u.email === email)) { alert('هذا البريد الإلكتروني مسجل بالفعل'); return; }
    const newUser = { name, email, password, grade, points: 0, quizzes: 0, progress: {}, achievements: [] };
    users.push(newUser);
    localStorage.setItem('noorUsers', JSON.stringify(users));
    localStorage.setItem('noorUser', JSON.stringify(newUser));
    closeAuthModal();
    updateLoginButton();
    renderValues();
    alert('تم إنشاء حسابك بنجاح! 🎉');
}

function closeAuthModal() { document.getElementById('authModal').classList.remove('active'); }
function logout() { localStorage.removeItem('noorUser'); updateLoginButton(); renderValues(); closeModal(); alert('تم تسجيل الخروج بنجاح'); }
function addPoints(points) { const user = JSON.parse(localStorage.getItem('noorUser') || '{}'); user.points = (user.points || 0) + points; localStorage.setItem('noorUser', JSON.stringify(user)); updateLoginButton(); }
function completeChallenge(challengeId) { const user = JSON.parse(localStorage.getItem('noorUser') || '{}'); if (!user.completedChallenges) user.completedChallenges = []; if (!user.completedChallenges.includes(challengeId)) { user.completedChallenges.push(challengeId); user.points = (user.points || 0) + 50; localStorage.setItem('noorUser', JSON.stringify(user)); } }
