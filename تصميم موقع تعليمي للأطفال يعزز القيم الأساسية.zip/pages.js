// صفحة الملف الشخصي
function showProfilePage() {
    const user = JSON.parse(localStorage.getItem('noorUser') || 'null');
    if (!user) { showLoginModal(); return; }
    const grades = {'7':'الأول متوسط','8':'الثاني متوسط','9':'الثالث متوسط'};
    const level = Math.floor((user.points || 0) / 100) + 1;
    const progress = ((user.points || 0) % 100);
    
    document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;">
            <div style="width: 100px; height: 100px; background: var(--gradient-1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; font-size: 3rem;">${user.name.charAt(0)}</div>
            <h2>${user.name}</h2>
            <p style="color: var(--text-secondary);">الصف ${grades[user.grade] || user.grade}</p>
            <div style="margin-top: 1rem;"><span style="background: var(--gradient-1); padding: 0.5rem 1rem; border-radius: 20px; font-size: 0.9rem;">المستوى ${level}</span></div>
            <div style="background: var(--bg-dark); height: 8px; border-radius: 4px; margin-top: 1rem; overflow: hidden;"><div style="background: var(--gradient-1); height: 100%; width: ${progress}%;"></div></div>
            <small style="color: var(--text-secondary);">${progress}/100 للمستوى التالي</small>
        </div>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 2rem;">
            <div style="background: var(--bg-dark); padding: 1rem; border-radius: 12px; text-align: center;"><div style="font-size: 2rem; color: var(--accent);">⭐</div><div style="font-size: 1.5rem; font-weight: bold;">${user.points || 0}</div><div style="color: var(--text-secondary); font-size: 0.9rem;">نقطة</div></div>
            <div style="background: var(--bg-dark); padding: 1rem; border-radius: 12px; text-align: center;"><div style="font-size: 2rem; color: var(--primary);">📝</div><div style="font-size: 1.5rem; font-weight: bold;">${user.quizzes || 0}</div><div style="color: var(--text-secondary); font-size: 0.9rem;">اختبار</div></div>
        </div>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
            <button onclick="showAchievementsPage()" class="btn-secondary" style="width: 100%;">🏆 إنجازاتي</button>
            <button onclick="logout()" style="background: var(--danger); color: white; border: none; padding: 1rem; border-radius: 12px; cursor: pointer; font-family: inherit;">تسجيل الخروج</button>
        </div>
    </div>`;
    document.getElementById('valueModal').classList.add('active');
}

function showAchievementsPage() {
    const user = JSON.parse(localStorage.getItem('noorUser') || 'null');
    if (!user) { showLoginModal(); return; }
    const achievements = [
        { id: 'first_quiz', title: 'الاختبار الأول', icon: '📝', desc: 'أكمل أول اختبار', unlocked: (user.quizzes || 0) >= 1 },
        { id: 'five_quizzes', title: 'متعلم نشيط', icon: '🎯', desc: 'أكمل 5 اختبارات', unlocked: (user.quizzes || 0) >= 5 },
        { id: 'first_100', title: 'أول 100 نقطة', icon: '⭐', desc: 'اجمع 100 نقطة', unlocked: (user.points || 0) >= 100 },
        { id: 'first_500', title: 'نجم القيم', icon: '🌟', desc: 'اجمع 500 نقطة', unlocked: (user.points || 0) >= 500 },
        { id: 'first_challenge', title: 'المتحدي', icon: '🏆', desc: 'أكمل أول تحدي', unlocked: (user.completedChallenges || []).length >= 1 },
        { id: 'all_challenges', title: 'بطل التحديات', icon: '👑', desc: 'أكمل جميع التحديات', unlocked: (user.completedChallenges || []).length >= 5 }
    ];
    const unlocked = achievements.filter(a => a.unlocked).length;
    document.getElementById('valueModal').innerHTML = `<div class="modal-content" style="padding: 2rem;">
        <button class="modal-close" onclick="closeModal()">×</button>
        <div style="text-align: center; margin-bottom: 2rem;"><span style="font-size: 4rem;">🏆</span><h2>إنجازاتي</h2><p style="color: var(--text-secondary);">${unlocked}/${achievements.length} إنجاز مفتوح</p></div>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
            ${achievements.map(a => `<div style="background: var(--bg-dark); padding: 1rem; border-radius: 12px; text-align: center; opacity: ${a.unlocked ? '1' : '0.5'}; border: 2px solid ${a.unlocked ? 'var(--accent)' : 'var(--border)'};"><div style="font-size: 2rem; ${a.unlocked ? '' : 'filter: grayscale(1);'}">${a.icon}</div><h4 style="margin: 0.5rem 0;">${a.title}</h4><p style="color: var(--text-secondary); font-size: 0.8rem;">${a.desc}</p>${a.unlocked ? '<span style="color: var(--success);">✓ مفتوح</span>' : '<span style="color: var(--text-secondary);">🔒</span>'}</div>`).join('')}
        </div>
        <button onclick="showProfilePage()" class="btn-secondary" style="width: 100%; margin-top: 1rem;">← العودة للملف الشخصي</button>
    </div>`;
}
