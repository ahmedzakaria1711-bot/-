import { describe, it, expect } from "vitest";

// اختبار بنية البيانات للمحتوى المخصص حسب المرحلة
describe("Stage Content Structure", () => {
  it("should have elementary and middle content properties defined", () => {
    // التحقق من أن واجهة StageContent تحتوي على الخصائص المطلوبة
    const stageContent = {
      description: "وصف تجريبي",
      activities: [
        { id: "test1", title: "نشاط تجريبي", type: "صفّي" as const, description: "وصف النشاط", status: "pending" as const }
      ],
      evidence: {
        positive: ["سلوك إيجابي"],
        needsSupport: ["يحتاج دعم"]
      },
      teacherTips: "نصائح للمعلم"
    };

    expect(stageContent).toHaveProperty("description");
    expect(stageContent).toHaveProperty("activities");
    expect(stageContent).toHaveProperty("evidence");
    expect(stageContent).toHaveProperty("teacherTips");
    expect(stageContent.activities).toBeInstanceOf(Array);
    expect(stageContent.evidence.positive).toBeInstanceOf(Array);
    expect(stageContent.evidence.needsSupport).toBeInstanceOf(Array);
  });

  it("should correctly identify education stage", () => {
    const elementaryGrades = ["الأول الابتدائي", "الثاني الابتدائي", "الثالث الابتدائي", "الرابع الابتدائي", "الخامس الابتدائي", "السادس الابتدائي"];
    const middleGrades = ["الأول المتوسط", "الثاني المتوسط", "الثالث المتوسط"];

    // التحقق من أن الصفوف الابتدائية تنتمي للمرحلة الابتدائية
    elementaryGrades.forEach(grade => {
      expect(grade).toContain("ابتدائي");
    });

    // التحقق من أن الصفوف المتوسطة تنتمي للمرحلة المتوسطة
    middleGrades.forEach(grade => {
      expect(grade).toContain("متوسط");
    });
  });

  it("should have correct activity types", () => {
    const validTypes = ["صفّي", "منزلي", "رقمي"];
    
    validTypes.forEach(type => {
      expect(["صفّي", "منزلي", "رقمي"]).toContain(type);
    });
  });

  it("should have correct activity status values", () => {
    const validStatuses = ["pending", "completed"];
    
    validStatuses.forEach(status => {
      expect(["pending", "completed"]).toContain(status);
    });
  });

  it("should select correct content based on stage", () => {
    const elementaryContent = {
      description: "محتوى للمرحلة الابتدائية",
      activities: [],
      evidence: { positive: [], needsSupport: [] },
      teacherTips: ""
    };

    const middleContent = {
      description: "محتوى للمرحلة المتوسطة",
      activities: [],
      evidence: { positive: [], needsSupport: [] },
      teacherTips: ""
    };

    const defaultDescription = "الوصف الافتراضي";

    // محاكاة اختيار المحتوى حسب المرحلة
    const getContentForStage = (stage: "elementary" | "middle" | null) => {
      if (stage === "elementary" && elementaryContent) {
        return elementaryContent.description;
      } else if (stage === "middle" && middleContent) {
        return middleContent.description;
      }
      return defaultDescription;
    };

    expect(getContentForStage("elementary")).toBe("محتوى للمرحلة الابتدائية");
    expect(getContentForStage("middle")).toBe("محتوى للمرحلة المتوسطة");
    expect(getContentForStage(null)).toBe("الوصف الافتراضي");
  });

  it("should have student with stage property", () => {
    const student = {
      id: "test-id",
      name: "طالب تجريبي",
      gender: "boy" as const,
      grade: "الأول الابتدائي",
      stage: "elementary" as const,
      progress: 0,
      points: 100,
      inventory: []
    };

    expect(student).toHaveProperty("stage");
    expect(["elementary", "middle"]).toContain(student.stage);
  });
});
