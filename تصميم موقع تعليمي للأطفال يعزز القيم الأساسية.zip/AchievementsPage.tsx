import { valuesData } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Star, Trophy, Medal, Crown, User, LogIn } from "lucide-react";
import { cn } from "@/lib/utils";
import { Footer } from "@/components/Footer";
import { useStudent } from "@/contexts/StudentContext";
import { LoginDialog } from "@/components/LoginDialog";

export default function AchievementsPage() {
  const { currentStudent } = useStudent();

  // Calculate total progress
  const totalProgress = Math.round(
    valuesData.reduce((acc, curr) => acc + curr.progress, 0) / valuesData.length
  );

  const getLevelBadge = (level: string) => {
    switch (level) {
      case "متميّز": return <Crown className="w-5 h-5 text-yellow-500" />;
      case "ثابت": return <Medal className="w-5 h-5 text-blue-500" />;
      case "نامي": return <Star className="w-5 h-5 text-green-500" />;
      default: return <div className="w-5 h-5 rounded-full bg-gray-200" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20">
      {/* Header Image */}
      <div className="h-[250px] w-full relative overflow-hidden">
        <img 
          src="/images/hero-achievements.png" 
          alt="Achievements" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#FDFBF7]/90" />
        
        <div className="absolute top-6 right-6 z-10">
          <Link href="/">
            <Button variant="secondary" size="icon" className="rounded-full shadow-lg bg-white/80 backdrop-blur-sm hover:bg-white">
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-8 text-center z-10">
          <div className="inline-flex items-center justify-center p-3 bg-white rounded-full shadow-lg mb-4 animate-bounce">
            <Trophy className="w-8 h-8 text-yellow-500" />
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-primary mb-2">إنجازاتي</h1>
          <p className="text-muted-foreground font-medium">
            {currentStudent 
              ? `مرحباً ${currentStudent.name}! تابع تقدمك في رحلة القيم`
              : "سجل دخولك لمتابعة إنجازاتك"
            }
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 mt-8">
        {/* Student Profile Card - Only show if logged in */}
        {currentStudent ? (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 mb-12">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className={`w-24 h-24 rounded-full border-4 ${currentStudent.gender === "girl" ? "border-pink-300 bg-pink-50" : "border-blue-300 bg-blue-50"} overflow-hidden`}>
                <img 
                  src={currentStudent.gender === "girl" ? "/images/guide-girl.png" : "/images/guide-boy.png"} 
                  alt="Avatar" 
                  className="w-full h-full object-cover" 
                />
              </div>
              <div className="text-center md:text-right flex-grow">
                <h2 className="text-2xl font-bold text-gray-800 mb-1">{currentStudent.name}</h2>
                <p className="text-muted-foreground mb-2">{currentStudent.email}</p>
                <p className="text-sm text-gray-500">{currentStudent.grade}</p>
              </div>
              <div className="flex flex-col items-center gap-2">
                <div className="flex items-center gap-2 bg-yellow-50 px-4 py-2 rounded-full border border-yellow-200">
                  <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                  <span className="font-bold text-yellow-700">{currentStudent.points} نقطة</span>
                </div>
                <span className="text-xs text-gray-500">مجموع النقاط</span>
              </div>
            </div>

            {/* Student Achievements */}
            {currentStudent.achievements && currentStudent.achievements.length > 0 && (
              <div className="mt-8 pt-6 border-t border-gray-100">
                <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <Medal className="w-5 h-5 text-blue-500" />
                  الإنجازات المكتسبة
                </h3>
                <div className="flex flex-wrap gap-3">
                  {currentStudent.achievements.map((achievement, index) => (
                    <div 
                      key={index}
                      className="bg-gradient-to-r from-yellow-100 to-orange-100 px-4 py-2 rounded-full border border-yellow-200 text-sm font-medium text-yellow-800"
                    >
                      🏆 {achievement}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Login Prompt */
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-12 mb-12 text-center">
            <div className="w-20 h-20 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
              <User className="w-10 h-10 text-gray-400" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-3">سجل دخولك لمتابعة إنجازاتك</h2>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              قم بتسجيل الدخول أو إنشاء حساب جديد لحفظ تقدمك ومتابعة إنجازاتك في رحلة القيم
            </p>
            <LoginDialog />
          </div>
        )}

        {/* Total Progress Card */}
        <div className="bg-white rounded-3xl p-8 shadow-xl mb-12 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400" />
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="text-center md:text-right">
              <h2 className="text-2xl font-bold mb-2">مستوى التقدم العام</h2>
              <p className="text-muted-foreground">مجموع نقاطك في جميع القيم الأخلاقية</p>
            </div>
            
            <div className="relative w-32 h-32 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="transparent"
                  className="text-gray-100"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="transparent"
                  strokeDasharray={351.86}
                  strokeDashoffset={351.86 - (351.86 * totalProgress) / 100}
                  className="text-primary transition-all duration-1000 ease-out"
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute text-2xl font-bold text-primary">{totalProgress}%</span>
            </div>
          </div>
        </div>

        {/* Values List */}
        <div className="grid gap-6">
          {valuesData.map((value) => {
            const Icon = value.icon;
            return (
              <div 
                key={value.id} 
                className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex flex-col sm:flex-row items-center gap-6 transition-transform hover:scale-[1.01]"
              >
                <div className={cn("w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 shadow-inner", value.color)}>
                  <Icon className="w-8 h-8" />
                </div>

                <div className="flex-grow text-center sm:text-right w-full">
                  <div className="flex items-center justify-center sm:justify-between mb-2">
                    <h3 className="text-xl font-bold">{value.title}</h3>
                    <div className="flex items-center gap-2 bg-gray-50 px-3 py-1 rounded-full border border-gray-100">
                      {getLevelBadge(value.level)}
                      <span className="text-sm font-bold text-gray-600">{value.level}</span>
                    </div>
                  </div>
                  
                  <div className="w-full bg-gray-100 rounded-full h-4 overflow-hidden">
                    <div 
                      className={cn("h-full transition-all duration-1000 ease-out rounded-full", value.color.split(" ")[0].replace("text-", "bg-"))}
                      style={{ width: `${value.progress}%` }}
                    />
                  </div>
                </div>

                <div className="shrink-0 text-center min-w-[100px]">
                  <span className="block text-3xl font-bold text-gray-800">{value.progress}%</span>
                  <span className="text-xs text-muted-foreground">إنجاز</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Teacher Tips Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          {valuesData.slice(0, 2).map((value) => (
            <div key={value.id} className="bg-yellow-50 rounded-2xl p-6 border border-yellow-100 relative">
              <div className="absolute -top-3 right-6 bg-yellow-400 text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                نصيحة المعلم
              </div>
              <p className="text-gray-700 mt-2 font-medium leading-relaxed">
                "{value.teacherTips}"
              </p>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
