import { valuesData } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";
import { ArrowRight, TrendingUp, TrendingDown, Users, Activity, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function AdminDashboard() {
  // Prepare data for charts
  const barData = valuesData.map(v => ({
    name: v.title,
    progress: v.progress,
    color: v.color.split(" ")[0].replace("text-", "") // Extract color name
  }));

  const pieData = [
    { name: "متميّز", value: 30, color: "#22c55e" },
    { name: "ثابت", value: 45, color: "#3b82f6" },
    { name: "نامي", value: 15, color: "#eab308" },
    { name: "ناشئ", value: 10, color: "#f97316" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold text-gray-800">لوحة الإدارة المدرسية</h1>
              <p className="text-xs text-muted-foreground">نظرة عامة على أداء القيم في المدرسة</p>
            </div>
          </div>
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            تصدير التقرير الشامل
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">متوسط تقدم القيم</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">78%</div>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                <TrendingUp className="w-3 h-3 text-green-500" />
                <span className="text-green-500 font-medium">+2.5%</span>
                من الشهر الماضي
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الطلاب النشطين</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,240</div>
              <p className="text-xs text-muted-foreground mt-1">
                95% من إجمالي الطلاب
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">القيمة الأكثر تطبيقاً</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">الصدق</div>
              <p className="text-xs text-muted-foreground mt-1">
                92% نسبة الإنجاز
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">القيمة الأقل تطبيقاً</CardTitle>
              <TrendingDown className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">تحمل المسؤولية</div>
              <p className="text-xs text-muted-foreground mt-1">
                45% نسبة الإنجاز
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Bar Chart */}
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>أداء القيم حسب الفئة</CardTitle>
              <CardDescription>مقارنة مستوى التقدم لكل قيمة أخلاقية</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                    cursor={{ fill: 'transparent' }}
                  />
                  <Bar dataKey="progress" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Pie Chart */}
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>توزيع مستويات الطلاب</CardTitle>
              <CardDescription>نسبة الطلاب في كل مستوى تقييمي</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Parent Reports Preview */}
        <Card>
          <CardHeader>
            <CardTitle>تقارير أولياء الأمور (معاينة)</CardTitle>
            <CardDescription>نموذج للتقرير الأسبوعي المرسل لأولياء الأمور</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4 border-b border-blue-200 pb-4">
                <div>
                  <h4 className="font-bold text-blue-900">تقرير الأداء الأسبوعي</h4>
                  <p className="text-sm text-blue-700">الفترة: 10 - 17 ديسمبر 2025</p>
                </div>
                <div className="text-left">
                  <span className="text-xs font-bold bg-white px-2 py-1 rounded text-blue-600 border border-blue-200">نسخة ولي الأمر</span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h5 className="text-xs font-bold text-gray-500 uppercase mb-2">نقاط القوة</h5>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li className="flex items-center gap-2">✅ الالتزام بالصدق في المواقف اليومية</li>
                    <li className="flex items-center gap-2">✅ التعاون الممتاز مع الزملاء</li>
                  </ul>
                </div>
                <div>
                  <h5 className="text-xs font-bold text-gray-500 uppercase mb-2">مجالات التطوير</h5>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li className="flex items-center gap-2">⚠️ الحاجة لتحسين الانضباط في الوقت</li>
                  </ul>
                </div>
                <div>
                  <h5 className="text-xs font-bold text-gray-500 uppercase mb-2">اقتراحات المنزل</h5>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    نرجو تشجيع الطالب على إعداد جدول يومي للمهام المنزلية لتعزيز قيمة الانضباط.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
