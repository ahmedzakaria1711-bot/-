import { Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100 py-8 mt-auto">
      <div className="container mx-auto px-4">
        {/* School Logo and Info */}
        <div className="flex flex-col items-center justify-center mb-6">
          <img 
            src="/images/school-logo.png" 
            alt="Madinat Al-Oloum International Schools" 
            className="w-20 h-20 object-contain mb-3"
          />
          <p className="text-sm font-semibold text-gray-700">مدارس مدينة العلوم العالمية</p>
          <p className="text-xs text-gray-500">Madinat Al-Oloum International Schools</p>
        </div>

        {/* Divider */}
        <div className="w-24 h-0.5 bg-gradient-to-r from-transparent via-gray-200 to-transparent mx-auto mb-6" />

        {/* Platform Info */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center text-white font-bold text-sm">ق</div>
            <span className="font-bold text-primary">قِيَمي</span>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            منصة تعليمية تهدف لغرس القيم الأخلاقية النبيلة في نفوس أبطال المستقبل.
          </p>
          <div className="flex items-center justify-center gap-1 text-xs text-gray-400">
            <span>صنع بحب</span>
            <Heart className="w-3 h-3 text-red-400 fill-red-400" />
            <span>لأجل مستقبل أفضل</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
