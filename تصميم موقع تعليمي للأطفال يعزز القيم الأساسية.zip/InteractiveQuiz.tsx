import { useState } from "react";
import { QuizQuestion } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { 
  CheckCircle2, 
  XCircle, 
  ArrowLeft, 
  Trophy, 
  RefreshCw,
  Lightbulb,
  Star
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";

interface InteractiveQuizProps {
  questions: QuizQuestion[];
  valueTitle: string;
  valueColor: string;
  onComplete?: (score: number) => void;
}

export function InteractiveQuiz({ questions, valueTitle, valueColor, onComplete }: InteractiveQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [answers, setAnswers] = useState<(number | null)[]>(new Array(questions.length).fill(null));

  const question = questions[currentQuestion];
  const isCorrect = selectedAnswer === question.correctAnswer;
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleSelectAnswer = (index: number) => {
    if (showResult) return;
    setSelectedAnswer(index);
  };

  const handleSubmit = () => {
    if (selectedAnswer === null) return;
    
    setShowResult(true);
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedAnswer;
    setAnswers(newAnswers);
    
    if (isCorrect) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      // إنهاء الاختبار
      setIsCompleted(true);
      const finalScore = score + (isCorrect ? 1 : 0);
      if (finalScore >= questions.length * 0.8) {
        // احتفال عند النجاح
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
      if (onComplete) {
        onComplete(finalScore);
      }
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setIsCompleted(false);
    setAnswers(new Array(questions.length).fill(null));
  };

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage === 100) return "ممتاز! أنت بطل حقيقي! 🏆";
    if (percentage >= 80) return "أحسنت! أداء رائع! 🌟";
    if (percentage >= 60) return "جيد! استمر في التعلم! 💪";
    return "حاول مرة أخرى! أنت تستطيع! 🎯";
  };

  const getScoreColor = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 80) return "from-green-500 to-emerald-500";
    if (percentage >= 60) return "from-yellow-500 to-orange-500";
    return "from-red-500 to-rose-500";
  };

  if (isCompleted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl overflow-hidden"
      >
        <div className={cn("p-8 text-white text-center bg-gradient-to-r", getScoreColor())}>
          <Trophy className="w-20 h-20 mx-auto mb-4" />
          <h2 className="text-3xl font-extrabold mb-2">انتهى الاختبار!</h2>
          <p className="text-xl opacity-90">{getScoreMessage()}</p>
        </div>

        <div className="p-8">
          {/* النتيجة */}
          <div className="text-center mb-8">
            <div className="text-6xl font-extrabold text-slate-800 mb-2">
              {score}/{questions.length}
            </div>
            <p className="text-slate-500">إجابات صحيحة</p>
          </div>

          {/* النجوم */}
          <div className="flex justify-center gap-2 mb-8">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={cn(
                  "w-10 h-10 transition-all",
                  i < Math.ceil((score / questions.length) * 5)
                    ? "text-yellow-400 fill-yellow-400"
                    : "text-slate-200"
                )}
              />
            ))}
          </div>

          {/* ملخص الإجابات */}
          <div className="space-y-2 mb-8">
            {questions.map((q, index) => (
              <div
                key={index}
                className={cn(
                  "flex items-center gap-3 p-3 rounded-xl",
                  answers[index] === q.correctAnswer
                    ? "bg-green-50 border border-green-200"
                    : "bg-red-50 border border-red-200"
                )}
              >
                {answers[index] === q.correctAnswer ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500 shrink-0" />
                )}
                <span className="text-sm text-slate-700 truncate">
                  السؤال {index + 1}: {q.question.slice(0, 40)}...
                </span>
              </div>
            ))}
          </div>

          <Button
            onClick={handleRestart}
            className="w-full gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
          >
            <RefreshCw className="w-5 h-5" />
            إعادة الاختبار
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-lg">اختبار {valueTitle}</h3>
          <span className="px-3 py-1 bg-white/20 rounded-full text-sm">
            {currentQuestion + 1}/{questions.length}
          </span>
        </div>
        {/* Progress Bar */}
        <div className="h-2 bg-white/20 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-green-400 to-emerald-400"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          className="p-6"
        >
          <div className="mb-6">
            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-3">
              السؤال {currentQuestion + 1}
            </span>
            <h2 className="text-xl font-bold text-slate-800 leading-relaxed">
              {question.question}
            </h2>
          </div>

          {/* Options */}
          <div className="space-y-3 mb-6">
            {question.options.map((option, index) => (
              <motion.button
                key={index}
                whileHover={{ scale: showResult ? 1 : 1.02 }}
                whileTap={{ scale: showResult ? 1 : 0.98 }}
                onClick={() => handleSelectAnswer(index)}
                disabled={showResult}
                className={cn(
                  "w-full p-4 rounded-2xl text-right transition-all border-2",
                  showResult
                    ? index === question.correctAnswer
                      ? "bg-green-50 border-green-500 text-green-800"
                      : selectedAnswer === index
                        ? "bg-red-50 border-red-500 text-red-800"
                        : "bg-slate-50 border-slate-200 text-slate-500"
                    : selectedAnswer === index
                      ? "bg-blue-50 border-blue-500 text-blue-800"
                      : "bg-slate-50 border-slate-200 text-slate-700 hover:border-blue-300 hover:bg-blue-50/50"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0",
                    showResult
                      ? index === question.correctAnswer
                        ? "bg-green-500 text-white"
                        : selectedAnswer === index
                          ? "bg-red-500 text-white"
                          : "bg-slate-300 text-slate-600"
                      : selectedAnswer === index
                        ? "bg-blue-500 text-white"
                        : "bg-slate-200 text-slate-600"
                  )}>
                    {showResult ? (
                      index === question.correctAnswer ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : selectedAnswer === index ? (
                        <XCircle className="w-5 h-5" />
                      ) : (
                        String.fromCharCode(65 + index)
                      )
                    ) : (
                      String.fromCharCode(65 + index)
                    )}
                  </div>
                  <span className="font-medium">{option}</span>
                </div>
              </motion.button>
            ))}
          </div>

          {/* Explanation */}
          <AnimatePresence>
            {showResult && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-6"
              >
                <div className={cn(
                  "p-4 rounded-2xl",
                  isCorrect ? "bg-green-50 border border-green-200" : "bg-amber-50 border border-amber-200"
                )}>
                  <div className="flex items-start gap-3">
                    <Lightbulb className={cn(
                      "w-5 h-5 shrink-0 mt-0.5",
                      isCorrect ? "text-green-600" : "text-amber-600"
                    )} />
                    <div>
                      <h4 className={cn(
                        "font-bold mb-1",
                        isCorrect ? "text-green-800" : "text-amber-800"
                      )}>
                        {isCorrect ? "إجابة صحيحة! 🎉" : "إجابة خاطئة"}
                      </h4>
                      <p className={cn(
                        "text-sm",
                        isCorrect ? "text-green-700" : "text-amber-700"
                      )}>
                        {question.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Actions */}
          <div className="flex gap-3">
            {!showResult ? (
              <Button
                onClick={handleSubmit}
                disabled={selectedAnswer === null}
                className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
              >
                تأكيد الإجابة
              </Button>
            ) : (
              <Button
                onClick={handleNext}
                className="flex-1 gap-2 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
              >
                {currentQuestion < questions.length - 1 ? "السؤال التالي" : "عرض النتيجة"}
                <ArrowLeft className="w-5 h-5" />
              </Button>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
