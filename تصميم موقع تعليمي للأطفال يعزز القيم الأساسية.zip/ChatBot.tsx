import { useState, useRef, useEffect } from "react";
import { BotMessage } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bot, Send, X, Sparkles, MessageCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

interface ChatBotProps {
  valueTitle: string;
  valueColor: string;
  botResponses: {
    greeting: string;
    encouragement: string[];
    hints: string[];
    completion: string;
  };
  isOpen: boolean;
  onClose: () => void;
}

export function ChatBot({ valueTitle, valueColor, botResponses, isOpen, onClose }: ChatBotProps) {
  const [messages, setMessages] = useState<BotMessage[]>([
    { role: "bot", content: botResponses.greeting }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    // ردود بناءً على الكلمات المفتاحية
    if (lowerMessage.includes("مساعدة") || lowerMessage.includes("ساعدني")) {
      return botResponses.hints[Math.floor(Math.random() * botResponses.hints.length)];
    }
    
    if (lowerMessage.includes("شكر") || lowerMessage.includes("ممتاز") || lowerMessage.includes("رائع")) {
      return "شكراً لك! أنت رائع أيضاً 🌟 هل لديك أسئلة أخرى عن " + valueTitle + "؟";
    }
    
    if (lowerMessage.includes("ما هي") || lowerMessage.includes("ما هو") || lowerMessage.includes("معنى")) {
      return `${valueTitle} هي قيمة إسلامية عظيمة. هل تريد أن أشرح لك المزيد؟ 📚`;
    }
    
    if (lowerMessage.includes("قصة") || lowerMessage.includes("مثال")) {
      return "هناك قصص كثيرة جميلة عن " + valueTitle + "! يمكنك مشاهدة العرض التقديمي لتتعرف على بعضها 📖";
    }
    
    if (lowerMessage.includes("اختبار") || lowerMessage.includes("أسئلة")) {
      return "ممتاز! يمكنك تجربة الاختبار التفاعلي لاختبار معلوماتك عن " + valueTitle + " 🎯";
    }
    
    if (lowerMessage.includes("نعم") || lowerMessage.includes("أريد") || lowerMessage.includes("طيب")) {
      return botResponses.encouragement[Math.floor(Math.random() * botResponses.encouragement.length)];
    }
    
    // رد افتراضي
    const defaultResponses = [
      `سؤال رائع! ${valueTitle} من أهم القيم التي يجب أن نتعلمها 💡`,
      `أحسنت على اهتمامك بتعلم ${valueTitle}! استمر في التعلم 🌟`,
      `هل تريد أن تعرف المزيد عن ${valueTitle}؟ يمكنني مساعدتك! 🤝`,
      botResponses.hints[Math.floor(Math.random() * botResponses.hints.length)]
    ];
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: BotMessage = { role: "user", content: inputValue };
    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // محاكاة تأخير الكتابة
    setTimeout(() => {
      const botResponse: BotMessage = { 
        role: "bot", 
        content: getBotResponse(inputValue) 
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSend();
    }
  };

  const quickReplies = [
    "ما معنى " + valueTitle + "؟",
    "أعطني مثالاً",
    "ساعدني",
    "شكراً"
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="fixed bottom-4 left-4 z-50 w-[350px] max-w-[calc(100vw-2rem)]"
        >
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
            {/* Header */}
            <div className={cn("p-4 text-white bg-gradient-to-r", valueColor.includes("blue") ? "from-blue-500 to-indigo-600" : "from-emerald-500 to-teal-600")}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <Bot className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">روبوت {valueTitle}</h3>
                    <div className="flex items-center gap-1 text-xs text-white/80">
                      <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                      متصل الآن
                    </div>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/20 rounded-full"
                  onClick={onClose}
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Messages */}
            <div className="h-[300px] overflow-y-auto p-4 space-y-4 bg-slate-50">
              {messages.map((message, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex",
                    message.role === "user" ? "justify-start" : "justify-end"
                  )}
                >
                  <div className={cn(
                    "max-w-[80%] p-3 rounded-2xl",
                    message.role === "user" 
                      ? "bg-blue-500 text-white rounded-br-sm" 
                      : "bg-white text-slate-700 shadow-sm border border-slate-100 rounded-bl-sm"
                  )}>
                    {message.role === "bot" && (
                      <div className="flex items-center gap-1 mb-1 text-xs text-slate-400">
                        <Sparkles className="w-3 h-3" />
                        روبوت القيم
                      </div>
                    )}
                    <p className="text-sm leading-relaxed">{message.content}</p>
                  </div>
                </motion.div>
              ))}
              
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-end"
                >
                  <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 rounded-bl-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></span>
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></span>
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></span>
                    </div>
                  </div>
                </motion.div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Replies */}
            <div className="px-4 py-2 border-t border-slate-100 bg-white">
              <div className="flex gap-2 overflow-x-auto pb-2">
                {quickReplies.map((reply, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setInputValue(reply);
                      setTimeout(() => handleSend(), 100);
                    }}
                    className="shrink-0 px-3 py-1.5 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-full transition-colors"
                  >
                    {reply}
                  </button>
                ))}
              </div>
            </div>

            {/* Input */}
            <div className="p-4 border-t border-slate-100 bg-white">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="اكتب رسالتك..."
                  className="flex-1 rounded-full bg-slate-100 border-0 focus-visible:ring-2 focus-visible:ring-blue-500"
                />
                <Button 
                  onClick={handleSend}
                  disabled={!inputValue.trim() || isTyping}
                  className="rounded-full w-10 h-10 p-0 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// زر فتح الروبوت
export function ChatBotTrigger({ onClick, valueColor }: { onClick: () => void; valueColor: string }) {
  return (
    <motion.button
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={cn(
        "fixed bottom-4 left-4 z-40 w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-white bg-gradient-to-r",
        valueColor.includes("blue") ? "from-blue-500 to-indigo-600" : "from-emerald-500 to-teal-600"
      )}
    >
      <MessageCircle className="w-6 h-6" />
      <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-[10px] font-bold">
        1
      </span>
    </motion.button>
  );
}
