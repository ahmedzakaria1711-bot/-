import { useState } from "react";
import { studentsData, valuesData } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, MessageCircle, Send, FileText, Bell } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Footer } from "@/components/Footer";

export default function ParentsPortal() {
  // Mock parent view for student "Ahmed"
  const student = studentsData[0];
  const [message, setMessage] = useState("");

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      toast.success("تم إرسال رسالتك إلى المعلم بنجاح 📨");
      setMessage("");
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20">
      {/* Header Image */}
      <div className="h-[200px] w-full relative overflow-hidden">
        <img 
          src="/images/hero-parents.png" 
          alt="Parents Portal" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#FDFBF7]/90" />
        
        <div className="absolute top-6 right-6 z-10">
          <Link href="/">
            <Button variant="secondary" size="icon" className="rounded-full shadow-lg bg-white/80 backdrop-blur-sm hover:bg-white">
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-8 text-center z-10">
          <h1 className="text-3xl font-extrabold text-primary mb-2">بوابة أولياء الأمور</h1>
          <p className="text-muted-foreground font-medium">نعمل معاً لبناء مستقبل أبنائنا</p>
        </div>
      </div>

      <main className="container mx-auto px-4 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Student Overview - Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Summary */}
            <Card className="border-none shadow-lg bg-white overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-blue-400 to-purple-400" />
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>ملخص أداء الطالب: {student.name}</span>
                  <span className="text-sm font-normal bg-blue-50 text-blue-600 px-3 py-1 rounded-full">
                    {student.grade}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {valuesData.slice(0, 4).map((value) => (
                    <div key={value.id} className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-bold text-gray-700">{value.title}</span>
                        <span className="text-xs font-bold text-gray-500">{value.level}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-blue-500 h-2.5 rounded-full" 
                          style={{ width: `${value.progress}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Notifications */}
            <Card className="border-none shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-yellow-500" />
                  آخر التنبيهات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4 items-start p-3 bg-green-50 rounded-lg border border-green-100">
                    <div className="w-2 h-2 mt-2 rounded-full bg-green-500 shrink-0" />
                    <div>
                      <p className="text-sm font-bold text-gray-800">إنجاز جديد!</p>
                      <p className="text-sm text-gray-600">أتم أحمد نشاط "الصدق" بنجاح وحصل على شارة التميز.</p>
                      <span className="text-xs text-gray-400 mt-1 block">منذ ساعتين</span>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start p-3 bg-blue-50 rounded-lg border border-blue-100">
                    <div className="w-2 h-2 mt-2 rounded-full bg-blue-500 shrink-0" />
                    <div>
                      <p className="text-sm font-bold text-gray-800">رسالة من المدرسة</p>
                      <p className="text-sm text-gray-600">نذكركم بموعد اجتماع أولياء الأمور يوم الخميس القادم.</p>
                      <span className="text-xs text-gray-400 mt-1 block">أمس</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Communication - Right Column */}
          <div className="lg:col-span-1">
            <Card className="border-none shadow-lg bg-white h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-primary" />
                  تواصل مع المعلم
                </CardTitle>
                <CardDescription>
                  يمكنك إرسال ملاحظاتك أو استفساراتك لمعلم الفصل مباشرة.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSendMessage} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">الموضوع</label>
                    <Input placeholder="مثال: استفسار عن الواجب المنزلي" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">الرسالة</label>
                    <Textarea 
                      placeholder="اكتب رسالتك هنا..." 
                      className="min-h-[150px]"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full gap-2">
                    <Send className="w-4 h-4" />
                    إرسال الرسالة
                  </Button>
                </form>

                <div className="mt-8 pt-6 border-t border-gray-100">
                  <h4 className="font-bold text-sm text-gray-700 mb-4">روابط سريعة</h4>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start gap-2 text-gray-600">
                      <FileText className="w-4 h-4" />
                      تحميل التقرير الشهري
                    </Button>
                    <Button variant="outline" className="w-full justify-start gap-2 text-gray-600">
                      <FileText className="w-4 h-4" />
                      الخطة الأسبوعية
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

        </div>
      </main>
      <Footer />
    </div>
  );
}
