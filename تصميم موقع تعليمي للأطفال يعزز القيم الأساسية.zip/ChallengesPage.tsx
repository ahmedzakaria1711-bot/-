import { challengesData } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Trophy, Timer, Users, Flame } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { Footer } from "@/components/Footer";

export default function ChallengesPage() {
  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20">
      {/* Header Image */}
      <div className="h-[250px] w-full relative overflow-hidden">
        <img 
          src="/images/hero-challenges.png" 
          alt="Classroom Challenges" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#FDFBF7]/90" />
        
        <div className="absolute top-6 right-6 z-10">
          <Link href="/">
            <Button variant="secondary" size="icon" className="rounded-full shadow-lg bg-white/80 backdrop-blur-sm hover:bg-white">
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-8 text-center z-10">
          <div className="inline-flex items-center justify-center p-3 bg-white rounded-full shadow-lg mb-4 animate-bounce">
            <Flame className="w-8 h-8 text-orange-500" />
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-primary mb-2">تحديات الفصل الكبرى</h1>
          <p className="text-muted-foreground font-medium">تعاون مع فريقك للفوز بالكأس!</p>
        </div>
      </div>

      <main className="container mx-auto px-4 mt-8">
        <div className="grid gap-8">
          {challengesData.map((challenge) => (
            <div key={challenge.id} className="bg-white rounded-3xl p-6 shadow-xl border-2 border-gray-100 relative overflow-hidden">
              {/* Decorative Background */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-50 rounded-bl-full opacity-50" />
              
              <div className="relative z-10 mb-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                      <Trophy className="w-6 h-6 text-yellow-500" />
                      {challenge.title}
                    </h2>
                    <p className="text-muted-foreground mt-1">{challenge.description}</p>
                  </div>
                  <div className="flex items-center gap-2 bg-red-50 text-red-500 px-4 py-2 rounded-full font-bold text-sm border border-red-100">
                    <Timer className="w-4 h-4" />
                    ينتهي في: {challenge.deadline}
                  </div>
                </div>

                {/* Teams Progress */}
                <div className="space-y-6 mt-8">
                  {challenge.teams
                    .sort((a, b) => b.progress - a.progress) // Sort by progress (Leaderboard)
                    .map((team, index) => {
                      const percentage = Math.min(100, Math.round((team.progress / challenge.target) * 100));
                      return (
                        <div key={team.id} className="relative">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-8 h-8 rounded-full flex items-center justify-center font-bold text-white shadow-sm",
                                index === 0 ? "bg-yellow-400 ring-4 ring-yellow-100" : 
                                index === 1 ? "bg-gray-400" : 
                                index === 2 ? "bg-orange-400" : "bg-blue-400"
                              )}>
                                {index + 1}
                              </div>
                              <span className="font-bold text-gray-700">{team.name}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm font-bold text-gray-500">
                              <Users className="w-4 h-4" />
                              {team.progress} / {challenge.target}
                            </div>
                          </div>
                          
                          <div className="h-6 bg-gray-100 rounded-full overflow-hidden shadow-inner relative">
                            <div 
                              className={cn("h-full transition-all duration-1000 ease-out relative", team.color)}
                              style={{ width: `${percentage}%` }}
                            >
                              {/* Striped pattern overlay */}
                              <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.2)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.2)_50%,rgba(255,255,255,0.2)_75%,transparent_75%,transparent)] bg-[length:20px_20px] animate-[move_1s_linear_infinite]" />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
