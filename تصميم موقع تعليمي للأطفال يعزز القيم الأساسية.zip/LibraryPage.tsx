import { Footer } from "@/components/Footer";
import { BookOpen, PlayCircle, Music } from "lucide-react";

export default function LibraryPage() {
  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-4 bg-purple-100 rounded-full mb-4">
            <BookOpen className="w-8 h-8 text-purple-600" />
          </div>
          <h1 className="text-4xl font-extrabold text-gray-800 mb-4">مكتبة القيم</h1>
          <p className="text-lg text-muted-foreground">قصص، فيديوهات، وأناشيد لتعزيز القيم الأخلاقية</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Stories Section */}
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center mb-4">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <h2 className="text-xl font-bold mb-2">قصص ملهمة</h2>
            <p className="text-gray-500 mb-4">مجموعة من القصص القصيرة الممتعة.</p>
            <div className="h-32 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 text-sm">
              قريباً...
            </div>
          </div>

          {/* Videos Section */}
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center mb-4">
              <PlayCircle className="w-6 h-6 text-red-600" />
            </div>
            <h2 className="text-xl font-bold mb-2">فيديوهات تعليمية</h2>
            <p className="text-gray-500 mb-4">مشاهد كرتونية تعلمك القيم.</p>
            <div className="h-32 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 text-sm">
              قريباً...
            </div>
          </div>

          {/* Audio Section */}
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center mb-4">
              <Music className="w-6 h-6 text-green-600" />
            </div>
            <h2 className="text-xl font-bold mb-2">أناشيد القيم</h2>
            <p className="text-gray-500 mb-4">أناشيد جميلة ومحفزة.</p>
            <div className="h-32 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 text-sm">
              قريباً...
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
