import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { StudentProvider } from "./contexts/StudentContext";
import Home from "./pages/Home";
import ActivityPage from "./pages/ActivityPage";
import AchievementsPage from "./pages/AchievementsPage";
import TeacherDashboard from "./pages/TeacherDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import StorePage from "./pages/StorePage";
import ParentsPortal from "./pages/ParentsPortal";
import ChallengesPage from "./pages/ChallengesPage";
import LibraryPage from "./pages/LibraryPage";
import { Sidebar } from "@/components/Sidebar";


function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/activity/:id"} component={ActivityPage} />
      <Route path={"/achievements"} component={AchievementsPage} />
      <Route path={"/teacher"} component={TeacherDashboard} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/store"} component={StorePage} />
      <Route path={"/parents"} component={ParentsPortal} />
      <Route path={"/challenges"} component={ChallengesPage} />
      <Route path={"/library"} component={LibraryPage} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <StudentProvider>
          <TooltipProvider>
            <Toaster />
            <Sidebar />
            <Router />
          </TooltipProvider>
        </StudentProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
