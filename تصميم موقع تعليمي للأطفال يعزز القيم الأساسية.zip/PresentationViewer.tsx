import { useState } from "react";
import { Slide } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { 
  ChevronRight, 
  ChevronLeft, 
  Play, 
  Pause, 
  Maximize2,
  BookOpen,
  Quote,
  Lightbulb,
  CheckCircle,
  HelpCircle,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

interface PresentationViewerProps {
  slides: Slide[];
  valueTitle: string;
  valueColor: string;
  onComplete?: () => void;
}

export function PresentationViewer({ slides, valueTitle, valueColor, onComplete }: PresentationViewerProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const slide = slides[currentSlide];
  const progress = ((currentSlide + 1) / slides.length) * 100;

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else if (onComplete) {
      onComplete();
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const getSlideIcon = (type: Slide["type"]) => {
    switch (type) {
      case "intro": return <Play className="w-6 h-6" />;
      case "definition": return <BookOpen className="w-6 h-6" />;
      case "evidence": return <Quote className="w-6 h-6" />;
      case "story": return <Lightbulb className="w-6 h-6" />;
      case "activity": return <CheckCircle className="w-6 h-6" />;
      case "summary": return <CheckCircle className="w-6 h-6" />;
      case "quiz": return <HelpCircle className="w-6 h-6" />;
      default: return <BookOpen className="w-6 h-6" />;
    }
  };

  const getSlideTypeLabel = (type: Slide["type"]) => {
    switch (type) {
      case "intro": return "مقدمة";
      case "definition": return "تعريف";
      case "evidence": return "شاهد شرعي";
      case "story": return "قصة";
      case "activity": return "نشاط";
      case "summary": return "ملخص";
      case "quiz": return "اختبار";
      default: return "";
    }
  };

  const getSlideBackground = (type: Slide["type"]) => {
    switch (type) {
      case "intro": return "from-blue-500 to-indigo-600";
      case "definition": return "from-emerald-500 to-teal-600";
      case "evidence": return "from-amber-500 to-orange-600";
      case "story": return "from-purple-500 to-pink-600";
      case "activity": return "from-cyan-500 to-blue-600";
      case "summary": return "from-green-500 to-emerald-600";
      case "quiz": return "from-rose-500 to-red-600";
      default: return "from-gray-500 to-gray-600";
    }
  };

  return (
    <div className={cn(
      "relative bg-white rounded-3xl shadow-2xl overflow-hidden",
      isFullscreen ? "fixed inset-4 z-50" : ""
    )}>
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", valueColor)}>
            {getSlideIcon(slide.type)}
          </div>
          <div>
            <h3 className="font-bold text-lg">{valueTitle}</h3>
            <p className="text-xs text-slate-300">الشريحة {currentSlide + 1} من {slides.length}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-white hover:bg-white/20"
            onClick={() => setIsFullscreen(!isFullscreen)}
          >
            {isFullscreen ? <X className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-1 bg-slate-200">
        <motion.div 
          className="h-full bg-gradient-to-r from-blue-500 to-indigo-500"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>

      {/* Slide Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          transition={{ duration: 0.3 }}
          className="p-8 min-h-[400px]"
        >
          {/* Slide Type Badge */}
          <div className="flex justify-center mb-6">
            <span className={cn(
              "px-4 py-1.5 rounded-full text-white text-sm font-bold bg-gradient-to-r",
              getSlideBackground(slide.type)
            )}>
              {getSlideTypeLabel(slide.type)}
            </span>
          </div>

          {/* Slide Title */}
          <h2 className="text-3xl font-extrabold text-center text-slate-800 mb-6">
            {slide.title}
          </h2>

          {/* Slide Content */}
          <div className="max-w-2xl mx-auto">
            {slide.type === "evidence" ? (
              <blockquote className="text-xl text-center text-slate-700 font-serif leading-relaxed bg-amber-50 p-6 rounded-2xl border-r-4 border-amber-500">
                "{slide.content}"
              </blockquote>
            ) : slide.type === "story" ? (
              <div className="bg-purple-50 p-6 rounded-2xl border border-purple-200">
                <p className="text-lg text-slate-700 leading-relaxed text-center">
                  {slide.content}
                </p>
              </div>
            ) : (
              <p className="text-xl text-center text-slate-600 leading-relaxed">
                {slide.content}
              </p>
            )}

            {/* Bullet Points */}
            {slide.bulletPoints && slide.bulletPoints.length > 0 && (
              <ul className="mt-6 space-y-3">
                {slide.bulletPoints.map((point, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3 bg-slate-50 p-4 rounded-xl"
                  >
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold bg-gradient-to-r",
                      getSlideBackground(slide.type)
                    )}>
                      {index + 1}
                    </div>
                    <span className="text-slate-700 font-medium">{point}</span>
                  </motion.li>
                ))}
              </ul>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="border-t border-slate-100 p-4 flex items-center justify-between bg-slate-50">
        <Button
          variant="outline"
          onClick={prevSlide}
          disabled={currentSlide === 0}
          className="gap-2"
        >
          <ChevronRight className="w-5 h-5" />
          السابق
        </Button>

        {/* Slide Dots */}
        <div className="flex gap-1.5 overflow-x-auto max-w-[200px] px-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={cn(
                "w-2.5 h-2.5 rounded-full transition-all shrink-0",
                index === currentSlide 
                  ? "bg-blue-500 w-6" 
                  : index < currentSlide 
                    ? "bg-green-400" 
                    : "bg-slate-300"
              )}
            />
          ))}
        </div>

        <Button
          onClick={nextSlide}
          className="gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
        >
          {currentSlide === slides.length - 1 ? "إنهاء" : "التالي"}
          <ChevronLeft className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
