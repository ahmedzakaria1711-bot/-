import { useState } from "react";
import { rewardsData, studentsData } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Coins, ShoppingBag, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Footer } from "@/components/Footer";

export default function StorePage() {
  // Mock current student (Ahmed)
  const [student, setStudent] = useState(studentsData[0]);

  const handleBuy = (rewardId: string, price: number) => {
    if (student.points >= price) {
      setStudent(prev => ({
        ...prev,
        points: prev.points - price,
        inventory: [...prev.inventory, rewardId]
      }));
      toast.success("تم شراء المكافأة بنجاح! 🎉");
    } else {
      toast.error("عذراً، ليس لديك نقاط كافية 😔");
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-20">
      {/* Header Image */}
      <div className="h-[250px] w-full relative overflow-hidden">
        <img 
          src="/images/hero-store.png" 
          alt="Magic Store" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#FDFBF7]/90" />
        
        <div className="absolute top-6 right-6 z-10">
          <Link href="/">
            <Button variant="secondary" size="icon" className="rounded-full shadow-lg bg-white/80 backdrop-blur-sm hover:bg-white">
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-8 text-center z-10">
          <div className="inline-flex items-center justify-center p-3 bg-white rounded-full shadow-lg mb-4 animate-bounce">
            <ShoppingBag className="w-8 h-8 text-purple-500" />
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-primary mb-2">متجر المكافآت السحري</h1>
          <p className="text-muted-foreground font-medium">استبدل نقاطك بجوائز رائعة!</p>
        </div>
      </div>

      <main className="container mx-auto px-4 mt-8">
        {/* Points Balance Card */}
        <div className="bg-white rounded-3xl p-6 shadow-xl mb-12 flex items-center justify-between border-2 border-yellow-100 max-w-2xl mx-auto relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-yellow-100 rounded-full opacity-50" />
          <div className="absolute -left-10 -bottom-10 w-32 h-32 bg-purple-100 rounded-full opacity-50" />
          
          <div className="relative z-10">
            <h2 className="text-lg font-bold text-gray-500 mb-1">رصيدك الحالي</h2>
            <div className="flex items-center gap-2">
              <Coins className="w-8 h-8 text-yellow-500 fill-yellow-500" />
              <span className="text-4xl font-extrabold text-gray-800">{student.points}</span>
              <span className="text-sm font-bold text-gray-400 mt-2">نقطة</span>
            </div>
          </div>
          
          <Button className="relative z-10 bg-yellow-400 hover:bg-yellow-500 text-yellow-900 font-bold rounded-xl h-12 px-6 shadow-md">
            كيف أجمع النقاط؟
          </Button>
        </div>

        {/* Rewards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {rewardsData.map((reward) => {
            const isOwned = student.inventory.includes(reward.id);
            const canAfford = student.points >= reward.price;

            return (
              <div 
                key={reward.id} 
                className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col items-center text-center transition-all hover:shadow-md hover:-translate-y-1 group"
              >
                <div className="w-full aspect-square bg-gray-50 rounded-xl mb-4 overflow-hidden relative p-4 flex items-center justify-center">
                  <img 
                    src={reward.image} 
                    alt={reward.title} 
                    className="w-full h-full object-contain transition-transform group-hover:scale-110"
                  />
                  {isOwned && (
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center backdrop-blur-[1px]">
                      <div className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1 shadow-lg">
                        <Check className="w-4 h-4" />
                        مملوك
                      </div>
                    </div>
                  )}
                </div>

                <h3 className="text-lg font-bold text-gray-800 mb-1">{reward.title}</h3>
                <span className="text-xs text-gray-400 mb-4 bg-gray-100 px-2 py-0.5 rounded-md">
                  {reward.type === "sticker" ? "ملصق" : "خلفية"}
                </span>

                <div className="mt-auto w-full">
                  {isOwned ? (
                    <Button disabled className="w-full bg-gray-100 text-gray-400 font-bold">
                      لديك بالفعل
                    </Button>
                  ) : (
                    <Button 
                      onClick={() => handleBuy(reward.id, reward.price)}
                      disabled={!canAfford}
                      className={cn(
                        "w-full font-bold gap-2",
                        canAfford 
                          ? "bg-purple-500 hover:bg-purple-600 text-white shadow-purple-200 shadow-lg" 
                          : "bg-gray-200 text-gray-400"
                      )}
                    >
                      <Coins className="w-4 h-4" />
                      {reward.price}
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </main>
      <Footer />
    </div>
  );
}
